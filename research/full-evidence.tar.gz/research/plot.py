"""Regenerate the review figure from the committed, historical JSON reports."""

import json
from pathlib import Path

import matplotlib.pyplot as plt


HERE = Path(__file__).resolve().parent
amazon = json.loads((HERE / "artifacts/amazon-report.json").read_text())
cross = json.loads((HERE / "artifacts/cross-dataset-report.json").read_text())

data = [("Amazon", amazon["pairs"]["C/A"])]
for label, target in [("KDD churn", "kdd_ctr"), ("Criteo", "criteo_ctr")]:
    cell = next(
        c for c in cross["cells"]
        if c["target"] == target and c["scenario"] == "predict"
        and c["block_size"] == 4096 and c["threads"] == 2
    )
    data.append((label, cell["pairs"]["C/A"]))

fig, ax = plt.subplots(figsize=(7.2, 3.3))
for y, (label, result) in enumerate(data):
    median = result["median_pct"]
    lower, upper = result["median_ci95_pct"]
    ax.errorbar(
        median, y,
        xerr=[[median - lower], [upper - median]],
        fmt="o", color="#145da0", markersize=7, capsize=4, linewidth=2,
    )
    ax.annotate(f"{median:.2f}%", (median, y), xytext=(8, 12),
                textcoords="offset points", fontsize=9)

ax.axvline(0, color="#999999", linewidth=1)
ax.set_yticks(range(len(data)), [label for label, _ in data])
ax.invert_yaxis()
ax.set_ylim(len(data) - 0.5, -0.7)
ax.set_xlim(-22, 1)
ax.set_xlabel("C/A latency change, % (lower is faster)")
ax.set_title("CatBoost v1.2.10 · CPU predict · batch 4096 · 2 threads")
ax.grid(axis="x", color="#dddddd", linewidth=0.7)
ax.set_axisbelow(True)
fig.tight_layout()
out = HERE / "figures/latency-4096-2threads.svg"
out.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(out, format="svg", metadata={"Date": None})
fig.savefig(out.with_suffix(".png"), dpi=180, metadata={"Software": "matplotlib"})
print(out)
