# Local check on CatBoost `d694ce0f`

This is a fresh local comparison of stock CatBoost (`A`) with the two CTR
inference changes on this branch (`C`). It is separate from the older v1.2.10
series. The [protocol](protocol.md) was written before the stock binary was
built and before the comparative measurements. All nine sessions per model
were kept; no outlier was removed.

The primary workload is CPU `predict` on a prepared Pool: 4096 rows, two
threads, 200 consecutive repetitions. `last_decile` in the harness means the
arithmetic mean of the last 20 repetitions **in execution order**. The point
estimate is the median of nine paired changes, and its 95% percentile interval
resamples entire paired sessions 20,000 times with seed 20261003.

| Model | A median, ms | C median, ms | Median paired C/A | 95% interval | Faster pairs |
|---|---:|---:|---:|---:|---:|
| Amazon | 2.3918 | 1.8970 | −20.76% | [−21.69%, −19.73%] | 9/9 |
| KDD 2009 churn | 7.0803 | 6.3595 | −9.38% | [−12.72%, −8.17%] | 9/9 |
| Criteo sample | 9.4271 | 8.7991 | −6.12% | [−8.19%, −5.53%] | 9/9 |

The A and C full-holdout hashes agreed before timing (6,554, 12,500 and
757,695 rows respectively). The exact cache hit/miss regression, known-key and
fallback fixture, and 4-thread shared-provider check returned `PASS`. The
CatBoost `model_ut` executable built and completed with exit code 0 (35
`[good]` test lines). These are runtime checks on this revision, but not a
ThreadSanitizer run; no race-free claim is inferred from them.

## Files

- [`run-1/manifest.json`](run-1/manifest.json): base revision, binary and input
  SHA-256 values, source/diff hashes, platform and workload.
- [`run-1/equivalence.json`](run-1/equivalence.json): full-holdout hashes and
  harness self-tests for both arms.
- [`run-1/raw.json`](run-1/raw.json): all 54 timed observations (3 models × 9
  sessions × 2 arms), including per-process results and binary hashes.
- [`run-1/report.json`](run-1/report.json): paired observations, median changes,
  bootstrap intervals and nine signs per model.
- [`run-1/cache-regression.json`](run-1/cache-regression.json),
  [`run-1/known-key.json`](run-1/known-key.json),
  [`run-1/shared-provider-race.json`](run-1/shared-provider-race.json): targeted
  C++ runtime checks. The original harness emits `cache_exercised` twice in the
  regression JSON with the same value; the output is preserved verbatim.
- [`plot.py`](plot.py) and [figure](latency-4096-2threads.svg): graph regenerated
  solely from the report JSON.
- [`run.py`](run.py): equivalence, paired timing and report generator.
- [`build-compat.patch`](build-compat.patch): local CMake compatibility changes
  for this macOS 26.6 / Apple M4 Pro / Apple clang 21 / CMake 4.4.3 build. This
  patch is **not** part of the proposed CatBoost code change.
- [`../harness/bench_harness.cpp`](../harness/bench_harness.cpp): exact source of
  the measured harness. The stock binary was compiled with
  `HARNESS_WITHOUT_CTR_CACHE` to exclude diagnostic calls unavailable in stock
  CatBoost. The common prediction loop and estimator were unchanged.

The measured binaries, full datasets and CatBoost build products are too large
for Git. Their SHA-256 values are in the manifest. The old research checkout
[`SRW2iter`](https://github.com/AndrewTheMaster/SRW2iter) holds the inputs; the
manifest records their exact content, while `run.py` takes its local path as an
argument. Given stock and candidate binaries, re-run the check with:

```sh
python3 research/current-master-20261003/run.py \
  --stock /path/to/stock/bench_harness \
  --candidate /path/to/candidate/bench_harness \
  --old-repo /path/to/SRW2iter \
  --out /path/to/not-yet-created-output-directory --sessions 9
```

The build was `Release`, profiling disabled. The local CMake patch was applied
temporarily, the harness source copied into
`catboost/tools/model_perftest/bench_harness.cpp`, and
`cmake --build build/Release --target bench_harness -j 4` produced each binary.
The stock binary used unmodified `static_ctr_provider.cpp/.h`; the candidate
used both code patches. Both were saved before timing. The patch, source and
binary hashes in `manifest.json` bind this description to the actual run.

The original model-training protocol, sample selection and older comparison
matrix are in [`../artifacts`](../artifacts). This check reused those models and
holdouts; it did not retrain them. The three values above are model-specific,
not a universal speedup. Pool creation, batch 1/128/1024, Linux x86-64 and
cold one-call inference were not remeasured on this revision.
