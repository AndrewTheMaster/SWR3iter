"""Recheck the two CTR patches against stock CatBoost on the same local host.

Inputs are kept in the earlier research checkout; only compact observations
and their hashes are published here. This script never changes either checkout.
"""

import argparse
import hashlib
import json
import platform
import random
import statistics
import subprocess
import sys
from pathlib import Path


def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def inputs(old):
    base = old / "results/local"
    cross = base / "cross-dataset-20260928"
    return {
        "amazon": (
            base / "perftest-20260920/baseline.cbm",
            base / "perftest-20260920/val.dsv",
            base / "perftest-20260920/val.cd",
        ),
        "kdd2009": (
            cross / "models/kdd2009_ctr.cbm",
            cross / "data/kdd2009/kdd2009_holdout_h.dsv",
            cross / "data/kdd2009/kdd2009.cd",
        ),
        "criteo": (
            cross / "models/criteo_ctr.cbm",
            cross / "data/criteo/criteo_holdout_h.dsv",
            cross / "data/criteo/criteo.cd",
        ),
    }


def call(binary, files, repetitions, full):
    cmd = [str(binary), "--model", str(files[0]), "--pool", str(files[1]),
           "--cd", str(files[2]), "--block-size", "4096", "--threads", "2",
           "--repetitions", str(repetitions)]
    if full:
        cmd.append("--full-dataset")
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode:
        raise RuntimeError(f"{binary.name} exited {proc.returncode}: "
                           f"{proc.stderr[-3000:]} {proc.stdout[-3000:]}")
    begin = proc.stdout.rfind("\n{\n")
    if begin < 0:
        raise RuntimeError(f"missing JSON from {binary.name}: {proc.stdout[-1000:]}")
    result = json.loads(proc.stdout[begin + 1:])
    if result["profile_enabled"] or result["scenario"] != "predict":
        raise RuntimeError("unexpected profiled or full-path benchmark")
    if result["predicted_rows"] != 4096:
        raise RuntimeError("unexpected predicted row count")
    return result


def median_bootstrap(values, seed, draws=20000):
    point = statistics.median(values)
    rng = random.Random(seed)
    n = len(values)
    samples = sorted(statistics.median(values[rng.randrange(n)] for _ in range(n))
                     for _ in range(draws))
    return point, [samples[int(0.025 * draws)], samples[int(0.975 * draws)]]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stock", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--old-repo", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--sessions", type=int, default=9)
    args = parser.parse_args()
    if args.sessions < 1 or args.out.exists():
        parser.error("sessions must be positive and output must not exist")
    binaries = {"A": args.stock.resolve(), "C": args.candidate.resolve()}
    for path in binaries.values():
        if not path.is_file():
            parser.error(f"missing binary: {path}")
    datasets = inputs(args.old_repo.resolve())
    for name, paths in datasets.items():
        for path in paths:
            if not path.is_file():
                parser.error(f"missing {name} input: {path}")

    args.out.mkdir(parents=True)
    manifest = {
        "base_commit": "d694ce0fa9df771fb7b6c42a13bcad5c23fdeec3",
        "platform": platform.platform(),
        "python": sys.version,
        "binary_sha256": {arm: sha256(path) for arm, path in binaries.items()},
        "input_sha256": {name: {kind: sha256(path) for kind, path in
                                   zip(("model", "pool", "cd"), paths)}
                          for name, paths in datasets.items()},
        "sessions_declared": args.sessions,
        "block_size": 4096,
        "threads": 2,
        "repetitions": 200,
        "steady_state_estimator": "mean of last 20 repetitions in execution order",
    }
    (args.out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")

    equivalence = {}
    for name, files in datasets.items():
        hashes = {}
        for arm in ("A", "C"):
            result = call(binaries[arm], files, 1, True)
            selftest = result["selftest"]
            if not all(selftest[key] is True for key in (
                    "subset_differs", "full_again_matches",
                    "copied_array_matches", "reloaded_model_matches",
                    "cloned_provider_matches")):
                raise RuntimeError(f"self-test failed for {name}/{arm}")
            hashes[arm] = result["full_dataset"]
        if hashes["A"]["pred_hash_full"] != hashes["C"]["pred_hash_full"]:
            raise RuntimeError(f"full-holdout prediction mismatch for {name}")
        if hashes["A"]["rows"] != hashes["C"]["rows"]:
            raise RuntimeError(f"full-holdout row count mismatch for {name}")
        equivalence[name] = hashes
        print(f"{name}: {hashes['A']['rows']} rows, "
              f"A=C {hashes['A']['pred_hash_full']}", flush=True)
    (args.out / "equivalence.json").write_text(json.dumps(equivalence, indent=2) + "\n")

    records = []
    raw_path = args.out / "raw.json"
    for name, files in datasets.items():
        for session in range(1, args.sessions + 1):
            order = ("A", "C") if session % 2 else ("C", "A")
            for arm in order:
                result = call(binaries[arm], files, 200, False)
                records.append({"dataset": name, "session": session, "arm": arm,
                                "binary_sha256": manifest["binary_sha256"][arm],
                                "result": result})
                raw_path.write_text(json.dumps(records, indent=2) + "\n")
            a = records[-2 if records[-2]["arm"] == "A" else -1]["result"]
            c = records[-2 if records[-2]["arm"] == "C" else -1]["result"]
            change = 100 * (c["per_rep_ms"]["last_decile"] /
                            a["per_rep_ms"]["last_decile"] - 1)
            print(f"{name} session {session}: C/A {change:+.2f}%", flush=True)

    report = {"provenance": manifest, "equivalence": {
        name: {"rows": e["A"]["rows"], "hash": e["A"]["pred_hash_full"]}
        for name, e in equivalence.items()}, "results": {}}
    for name in datasets:
        pairs = []
        for session in range(1, args.sessions + 1):
            pair = {r["arm"]: r["result"]["per_rep_ms"]["last_decile"]
                    for r in records if r["dataset"] == name and r["session"] == session}
            if set(pair) != {"A", "C"}:
                raise RuntimeError(f"incomplete pair {name}/{session}")
            pairs.append({"session": session, "A_ms": pair["A"], "C_ms": pair["C"],
                          "change_pct": 100 * (pair["C"] / pair["A"] - 1)})
        point, interval = median_bootstrap([p["change_pct"] for p in pairs], 20261003)
        report["results"][name] = {
            "A_median_ms": statistics.median(p["A_ms"] for p in pairs),
            "C_median_ms": statistics.median(p["C_ms"] for p in pairs),
            "median_paired_change_pct": point,
            "median_paired_change_ci95_pct": interval,
            "winning_sessions": sum(p["change_pct"] < 0 for p in pairs),
            "pairs": pairs,
        }
    (args.out / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({n: {k: v for k, v in r.items() if k != "pairs"}
                      for n, r in report["results"].items()}, indent=2), flush=True)


if __name__ == "__main__":
    main()
