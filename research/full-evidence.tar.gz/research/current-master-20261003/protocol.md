# Current-master local verification protocol

Recorded before the stock binary was built and before comparative measurements.
The candidate binary had only been built and given one Amazon smoke test.

## Revision and arms

- CatBoost base: `d694ce0fa9df771fb7b6c42a13bcad5c23fdeec3` (`fork/master`).
- A: that base, without CTR changes.
- C: the same base plus `reuse-ctr-buckets` and `ctr-prep-cache`.
- Identical local macOS arm64 CMake compatibility changes and the same benchmark
  harness are used for both. They are build-only and excluded from the review diff.
- CMake profiling is disabled. Binaries, source diff and input SHA-256 values
  are recorded in the result directory.
- The stock harness is compiled with `HARNESS_WITHOUT_CTR_CACHE` so its
  cache-specific diagnostic branches are absent; the common prediction loop
  and its estimator are identical. This is required because stock CatBoost
  does not have the diagnostic methods introduced by the candidate patch.

## Workload and checks

Primary cells are Amazon Employee Access, KDD Cup 2009 churn, and Criteo Click
Logs sample, each at block size 4096, two threads, 200 consecutive repetitions
on a prepared Pool. Use the existing CatBoost models and held-out DSV files from
SRW2iter, so this checks the port to the current CatBoost revision, not model
training. The warm steady-state estimator is the arithmetic mean of the **last
20 repetitions in execution order**. It is not the fastest decile.

First compare A and C prediction hashes over the full holdout, plus the
harness self-test. A mismatch blocks timing. Run nine paired sessions per model,
alternating A/C and C/A order. One session is one fresh process per arm. Keep
all sessions. The primary estimate is the median of nine paired `C/A - 1`
percent changes. The interval is a 95% percentile bootstrap of that median
with 20,000 resamples of entire paired sessions and seed 20261003. Also report
all nine signs, arm latencies and the raw observations. Negative is faster.

The historical data and chart elsewhere in this directory are a separate
CatBoost v1.2.10 experiment. Do not pool them with these measurements or claim
their point estimates reproduced on this revision without checking.

## Interpretation

The result is limited to this machine, these three models, this DSV input path,
and steady-state CPU prediction. A negative or uncertain result remains in the
report. Linux x86-64, a cold one-call request, Pool creation and upstream
test-suite coverage are outside this local verification.
