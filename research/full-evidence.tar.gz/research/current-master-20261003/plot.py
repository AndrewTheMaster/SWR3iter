"""Render the current-master result from the committed report JSON."""

import json
from pathlib import Path

import matplotlib.pyplot as plt


here = Path(__file__).resolve().parent
report = json.loads((here / "run-1/report.json").read_text())
data = [(label, report["results"][key]) for label, key in
        [("Amazon", "amazon"), ("KDD churn", "kdd2009"), ("Criteo", "criteo")]]

fig, ax = plt.subplots(figsize=(7.3, 3.3))
for y, (label, result) in enumerate(data):
    median = result["median_paired_change_pct"]
    low, high = result["median_paired_change_ci95_pct"]
    ax.errorbar(median, y, xerr=[[median - low], [high - median]], fmt="o",
                color="#145da0", markersize=7, capsize=4, linewidth=2)
    ax.annotate(f"{median:.1f}%", (median, y), xytext=(8, 12),
                textcoords="offset points", fontsize=9)

ax.axvline(0, color="#999999", linewidth=1)
ax.set_yticks(range(len(data)), [label for label, _ in data])
ax.invert_yaxis()
ax.set_ylim(len(data) - 0.5, -0.7)
ax.set_xlim(-25, 1)
ax.set_xlabel("C/A latency change, % (lower is faster)")
ax.set_title("CatBoost d694ce0f · CPU predict · batch 4096 · 2 threads")
ax.grid(axis="x", color="#dddddd", linewidth=0.7)
ax.set_axisbelow(True)
fig.tight_layout()
out = here / "latency-4096-2threads.svg"
fig.savefig(out, format="svg", metadata={"Date": None})
fig.savefig(out.with_suffix(".png"), dpi=180, metadata={"Software": "matplotlib"})
print(out)
