# Historical uncompressed raw files

The original JSON files are in the local SRW2iter research checkout. Their
SHA-256 values are preserved here separately from `SHA256SUMS`, whose entries
refer only to files committed in this directory and can be verified with
`shasum -a 256 -c SHA256SUMS`.

| File | SHA-256 |
|---|---|
| `amazon-raw.json` | `336043f1c69fa3cff4f76a381734a982a658fcdc5a46c3a0c950b2bc7e78dee7` |
| `cross-dataset-raw.json` | `95836412023b2737967c5f4ea276d4b3cd2ef81dae0975f718eb989b32d7094c` |
