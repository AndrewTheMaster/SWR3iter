// Standalone benchmark harness for the CatBoost CPU evaluator.
//
// Deliberately free of any profiling dependency: the Step 4 evidence is a plain
// A/B/C end-to-end benchmark, not phase timings. The Pool is built once before
// the measured loop, so data preparation never mixes into inference, and the
// harness reports per-repetition statistics so a warm-up transient can be
// excluded from the comparison.
//
// It also prints a checksum of the full prediction vector for a single call, so
// variants can be compared for bit-identical output.
#include <catboost/libs/model/model.h>
#ifdef HARNESS_WITH_PHASE_PROFILE
// Phase reporting is opt-in at compile time. Without this macro the harness has
// no dependency on the profiling header, so a production or unified build
// cannot pick up leftover instrumentation from a previous build.
#include <catboost/libs/model/phase_profile.h>
#define HARNESS_HAS_PHASE_PROFILE 1
#endif
#include <catboost/libs/model/hash.h>
#include <catboost/libs/model/static_ctr_provider.h>
#include <catboost/libs/model/cpu/evaluator.h>
#include <catboost/libs/data/load_data.h>
#include <catboost/libs/logging/logging.h>
#include <catboost/libs/helpers/exception.h>
#include <catboost/private/libs/algo/features_data_helpers.h>

#include <library/cpp/threading/local_executor/local_executor.h>
#include <library/cpp/threading/future/async.h>
#include <util/generic/array_ref.h>
#include <util/generic/vector.h>
#include <util/system/hp_timer.h>
#include <util/system/info.h>
#include <util/thread/pool.h>

#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <atomic>
#include <thread>

#include <mach/mach.h>
#include <vector>

using namespace NCB;

namespace {

struct TOptions {
    TString modelPath;
    TString poolPath;
    TString cdPath;
    size_t blockSize = 4096;
    size_t repetitions = 200;
    int threads = 1;
    TString raceTest;        // "shared", "shared-cold" or "independent"
    TString lifecycleTest;
    TString cacheRegression;
    TString knownKeyTest;
    bool fullDataset = false;
    // S2: the full path from raw categorical strings. The Pool is rebuilt from
    // the DSV inside every repetition, so the categorical hashing path runs each
    // time; the two phases are timed separately and never mixed into one metric.
    bool fullPath = false;
    bool runServeTest = false;
    int lifecycleIterations = 400;
    int lifecycleThreads = 2;
    int raceThreads = 4;
    int raceIterations = 2000;
    // Serve: one shared model and CtrProvider answering concurrent predict
    // requests, while models are loaded and dropped underneath.
    int serveThreads = 4;
    int serveIterations = 200;
    int serveLoaders = 1;
    int serveLoadIters = 20;
};

// FNV-1a over the raw bits of the prediction vector.
struct TFnv {
    uint64_t State = 1469598103934665603ULL;
    void Update(const void* data, size_t size) {
        const auto* bytes = static_cast<const unsigned char*>(data);
        for (size_t i = 0; i < size; ++i) {
            State ^= bytes[i];
            State *= 1099511628211ULL;
        }
    }
    void Print(std::string* out) const {
        unsigned char digest[8];
        uint64_t v = State;
        for (int i = 0; i < 8; ++i) {
            digest[i] = static_cast<unsigned char>((v >> (i * 8)) & 0xFF);
        }
        out->assign(16, '0');
        static const char* hex = "0123456789abcdef";
        for (int i = 0; i < 8; ++i) {
            (*out)[2 * i] = hex[digest[i] >> 4];
            (*out)[2 * i + 1] = hex[digest[i] & 0x0f];
        }
    }

    void Print() const {
        unsigned char digest[8];
        uint64_t v = State;
        for (int i = 0; i < 8; ++i) {
            digest[i] = static_cast<unsigned char>((v >> (i * 8)) & 0xFF);
        }
        for (int i = 0; i < 8; ++i) {
            std::printf("%02x", digest[i]);
        }
    }
};

// Current resident set size of this process, for observing cache-related growth.
long CurrentRssBytes() {
    struct mach_task_basic_info info;
    mach_msg_type_number_t count = MACH_TASK_BASIC_INFO_COUNT;
    if (task_info(mach_task_self(), MACH_TASK_BASIC_INFO,
                  (task_info_t)&info, &count) != KERN_SUCCESS) {
        return 0;
    }
    return (long)info.resident_size;
}

}  // namespace

int main(int argc, char** argv) try {
    TOptions opts;
    for (int i = 1; i < argc; ++i) {
        TString a = argv[i];
        auto next = [&]() -> TString { return (i + 1 < argc) ? argv[++i] : ""; };
        if (a == "--model") opts.modelPath = next();
        else if (a == "--pool") opts.poolPath = next();
        else if (a == "--cd") opts.cdPath = next();
        else if (a == "--block-size") opts.blockSize = (size_t)std::atoll(next().c_str());
        else if (a == "--repetitions") opts.repetitions = (size_t)std::atoll(next().c_str());
        else if (a == "--threads") opts.threads = std::atoi(next().c_str());
        else if (a == "--cache-regression") opts.cacheRegression = next();
        else if (a == "--known-key-test") opts.knownKeyTest = next();
        else if (a == "--full-dataset") opts.fullDataset = true;
        else if (a == "--lifecycle-test") opts.lifecycleTest = next();
        else if (a == "--lifecycle-iterations") opts.lifecycleIterations = std::atoi(next().c_str());
        else if (a == "--lifecycle-threads") opts.lifecycleThreads = std::atoi(next().c_str());
        else if (a == "--race-test") opts.raceTest = next();
        else if (a == "--race-threads") opts.raceThreads = std::atoi(next().c_str());
        else if (a == "--race-iterations") opts.raceIterations = std::atoi(next().c_str());
        else if (a == "--full-path") opts.fullPath = true;
        else if (a == "--serve-test") { opts.serveThreads = std::atoi(next().c_str()); opts.runServeTest = true; }
        else if (a == "--serve-iterations") opts.serveIterations = std::atoi(next().c_str());
        else if (a == "--serve-loaders") opts.serveLoaders = std::atoi(next().c_str());
        else if (a == "--serve-load-iters") opts.serveLoadIters = std::atoi(next().c_str());
        else { std::fprintf(stderr, "unknown arg %s\n", a.c_str()); return 2; }
    }

#ifndef HARNESS_WITHOUT_CTR_CACHE
    if (!opts.knownKeyTest.empty()) {
        // Known keys with distinguishable values, and a controlled missing key.
        //
        // The regression above checks hit/miss and equality against an uncached
        // computation, but it does not check that a *known* key produces the value
        // stored for it, nor that an unknown key takes the provider's fallback
        // branch. Both are checked here on a purpose-built table, which the public
        // AddCtrCalcerData makes possible without touching the training code.
        //
        // The projection is synthetic: exactly one categorical feature and no bin or
        // one-hot features, so the CTR hash is CalcHash(0, hashed[doc]) and the
        // value placed in `hashed` fully determines the key. Two keys are inserted
        // into the table; the remaining documents carry values chosen so that
        // GetIndex returns NotFoundIndex for them, which is verified rather than
        // assumed.
        TFullModel model = ReadModel(opts.modelPath);
        const size_t kDocs = 6;
        const size_t kKnown = 2;
        const int denominator = 4;

        TFeatureCombination projection;
        projection.CatFeatures = {0};   // feature-major, docCount per feature
        projection.BinFeatures.clear();
        projection.OneHotFeatures.clear();

        TModelCtrBase base;
        base.Projection = projection;
        base.CtrType = ECtrType::Counter;

        // Candidate key values; the first two go into the table, the rest are
        // filtered until they are provably absent.
        TVector<ui32> keyValue(kDocs);
        for (size_t d = 0; d < kDocs; ++d) {
            keyValue[d] = (ui32)(1000 + d);
        }
        auto hashOf = [&](ui32 value) {
            return CalcHash(0ull, (ui64)value);
        };

        // Built on demand: a TCtrValueTable is moved into a provider, so a copy
        // taken afterwards would be a moved-from object. Copying the builder input
        // instead of the result is the only way to get a second identical table.
        auto makeTable = [&]() {
            TCtrValueTable table;
            table.ModelCtrBase = base;
            table.CounterDenominator = denominator;
            table.TargetClassesCount = 1;
            auto builder = table.GetIndexHashBuilder(kKnown);
            TArrayRef<int> blob = table.AllocateBlobAndGetArrayRef<int>(kKnown);
            for (size_t k = 0; k < kKnown; ++k) {
                const ui32 index = builder.AddIndex(hashOf(keyValue[k]));
                blob[index] = (int)(k + 1);      // distinguishable: 1 and 2
            }
            return table;
        };
        TCtrValueTable probe = makeTable();
        auto viewer = probe.GetIndexHashViewer();
        size_t absentFrom = kDocs;
        for (size_t d = kKnown; d < kDocs; ++d) {
            if (viewer.GetIndex(hashOf(keyValue[d])) == NCatboost::TDenseIndexHashView::NotFoundIndex) {
                absentFrom = d;
                break;
            }
        }
        if (absentFrom == kDocs) {
            std::fprintf(stderr, "не найдено значение ключа, отсутствующего в таблице\n");
            return 2;
        }
        model.CtrProvider->AddCtrCalcerData(makeTable());

        // Move the absent key to a known position so the report is unambiguous.
        std::swap(keyValue[2], keyValue[absentFrom]);
        for (size_t d = 2; d < kDocs; ++d) {
            if (viewer.GetIndex(hashOf(keyValue[d]))
                != NCatboost::TDenseIndexHashView::NotFoundIndex) {
                std::fprintf(stderr, "значение ключа %u неожиданно присутствует\n", keyValue[d]);
                return 2;
            }
        }

        const size_t kBuckets = model.ModelTrees->GetEffectiveBinaryFeaturesBucketsCount();
        TVector<ui8> binarized(kDocs * kBuckets, 0);
        TVector<ui32> hashed(kDocs, 0);
        for (size_t d = 0; d < kDocs; ++d) {
            hashed[d] = keyValue[d];
        }
        TVector<TModelCtr> needed(1);
        needed[0].Base = base;

        // A TModelCtr computes a value from a table row, so the expected numbers
        // come from the same public formula the provider uses.
        TModelCtr expectedCtr;
        expectedCtr.Base = base;
        const float fallback = expectedCtr.Calc(0, denominator);
        const float expectKnown0 = expectedCtr.Calc(1, denominator);
        const float expectKnown1 = expectedCtr.Calc(2, denominator);

        auto compute = [&](const TIntrusivePtr<ICtrProvider>& provider,
                           TVector<float>* out) {
            provider->CalcCtrs(needed, binarized, hashed, kDocs, MakeArrayRef(*out));
        };

        int failures = 0;
        int checks = 0;
        const char* names[3] = {"known_key_0", "known_key_1", "missing_key"};

        // Three calls over the SAME data. The first populates the cache, the rest
        // must be served from it, and all three must be bitwise identical to a
        // freshly loaded model -- so a cache that returned a wrong value for a
        // known key, or that mishandled the missing key, would be caught.
        std::vector<std::vector<float>> results;
        for (int call = 0; call < 3; ++call) {
            const TIntrusivePtr<ICtrProvider> provider =
                (call == 0) ? model.CtrProvider : model.CtrProvider;
            TVector<float> out(kDocs, -1.0f);
            compute(provider, &out);
            results.push_back(out);
        }
        TFullModel fresh = ReadModel(opts.modelPath);
        fresh.CtrProvider->AddCtrCalcerData(makeTable());
        TVector<float> reference(kDocs, -1.0f);
        compute(fresh.CtrProvider, &reference);

        auto expectAt = [&](size_t doc) {
            if (doc < kKnown) {
                return doc == 0 ? expectKnown0 : expectKnown1;
            }
            return fallback;
        };
        for (size_t doc = 0; doc < kDocs; ++doc) {
            ++checks;
            if (results[0][doc] != expectAt(doc)) {
                ++failures;
                std::fprintf(stderr,
                    "док %zu: получено %.9g, ожидалось %.9g\n",
                    doc, (double)results[0][doc], (double)expectAt(doc));
            }
        }
        for (size_t call = 1; call < results.size(); ++call) {
            ++checks;
            if (results[call] != reference) {
                ++failures;
                std::fprintf(stderr, "вызов %zu разошёлся с некешированным эталоном\n", call);
            }
        }
        // The known values must actually be distinguishable, otherwise the check
        // above could pass on a provider that returned one constant for everything.
        ++checks;
        if (!(results[0][0] != results[0][1] && results[0][0] != fallback
              && results[0][1] != fallback)) {
            ++failures;
            std::fprintf(stderr, "известные значения неразличимы: %.9g %.9g fallback %.9g\n",
                         (double)results[0][0], (double)results[0][1], (double)fallback);
        }

        std::printf("{\n");
        std::printf("  \"known_key_test\": \"%s\",\n", opts.knownKeyTest.c_str());
        std::printf("  \"documents\": %zu,\n", kDocs);
        std::printf("  \"known_keys\": %zu,\n", kKnown);
        std::printf("  \"first_absent_key_value\": %u,\n", keyValue[2]);
        std::printf("  \"checks\": %d,\n", checks);
        std::printf("  \"values\": [");
        for (size_t doc = 0; doc < kDocs; ++doc) {
            std::printf("%s%.9g", doc ? ", " : "", (double)results[0][doc]);
        }
        std::printf("],\n");
        std::printf("  \"expected\": [");
        for (size_t doc = 0; doc < kDocs; ++doc) {
            std::printf("%s%.9g", doc ? ", " : "", (double)expectAt(doc));
        }
        std::printf("],\n");
        std::printf("  \"fallback_value\": %.9g,\n", (double)fallback);
        std::printf("  \"reference\": [");
        for (size_t doc = 0; doc < kDocs; ++doc) {
            std::printf("%s%.9g", doc ? ", " : "", (double)reference[doc]);
        }
        std::printf("],\n");
        std::printf("  \"cached_equals_uncached\": %s,\n",
                    (results[1] == reference && results[2] == reference) ? "true" : "false");
        std::printf("  \"named_checks\": [\"%s\", \"%s\", \"%s\", \"cached_equals_uncached\", "
                    "\"values_distinguishable\"]", names[0], names[1], names[2]);
        std::printf(",\n");
        std::printf("  \"failures\": %d,\n", failures);
        std::printf("  \"verdict\": \"%s\"\n", failures == 0 ? "PASS" : "FAIL");
        std::printf("}\n");
        return failures == 0 ? 0 : 1;
    }
#endif

#ifndef HARNESS_WITHOUT_CTR_CACHE
    if (!opts.cacheRegression.empty()) {
        // Regression for the cache-validation defect found in review (R1, G4).
        //
        // CompressModelCtrs stores pointers INTO the caller's array, so a validation
        // that compares those pointers with the array compares each element with
        // itself and accepts any in-place change of the grouping. The snapshot
        // comparison in the provider fixes that.
        //
        // This test therefore asserts on the exact hit/miss DELTA of each call, with
        // the counters sampled immediately before and immediately after it. Two
        // consequences, both learned the hard way:
        //   * no reference call may sit between the two samples -- the counters are
        //     per-thread and shared by every provider, so a reference call in
        //     between would move the baseline and let a wrong hit pass as a miss;
        //   * a fresh provider address does NOT imply a miss: the thread-local
        //     registry is keyed by address and the allocator may reuse one. So no
        //     check here relies on that; references are made with a freshly loaded
        //     model and are never counted.
        TFullModel model = ReadModel(opts.modelPath);
        const auto& usedCtrs = model.ModelTrees->GetApplyData()->UsedModelCtrs;
        const size_t ctrCount = usedCtrs.size();
        const size_t kDocCount = 4;
        const size_t kBuckets = model.ModelTrees->GetEffectiveBinaryFeaturesBucketsCount();
        const size_t kBufferSize = 3;

        // neededCtrs must be strictly increasing upstream, and UsedModelCtrs is
        // sorted, so every layout below is a subsequence of it. Verified here, not
        // assumed: a release build happily accepts a layout upstream would reject.
        struct TProjectionRange {
            size_t Begin = 0;
            size_t End = 0;  // exclusive
        };
        std::vector<TProjectionRange> ranges;
        for (size_t i = 0; i < ctrCount;) {
            size_t j = i + 1;
            while (j < ctrCount
                   && usedCtrs[j].Base.Projection == usedCtrs[i].Base.Projection) {
                ++j;
            }
            if (j - i >= 2) {
                ranges.push_back({i, j});
            }
            i = j;
        }
        if (ranges.size() < 3) {
            std::fprintf(stderr,
                "model needs three projections with >=2 CTRs to exercise the cache, "
                "found %zu\n", ranges.size());
            return 2;
        }
        const TProjectionRange pA = ranges[0];
        const TProjectionRange pB = ranges[1];
        const TProjectionRange pC = ranges[2];

        // Projections really are distinct and members really belong to them.
        auto sameProjection = [&](size_t a, size_t b) {
            return usedCtrs[a].Base.Projection == usedCtrs[b].Base.Projection;
        };
        if (sameProjection(pA.Begin, pB.Begin) || sameProjection(pB.Begin, pC.Begin)
            || sameProjection(pA.Begin, pC.Begin)) {
            std::fprintf(stderr, "selected projections are not distinct\n");
            return 2;
        }

        const std::array<std::array<size_t, 3>, 4> kLayouts = {{
            {{pA.Begin,     pA.Begin + 1, pB.Begin}},     // 0: [P, P, Q]
            {{pA.Begin,     pB.Begin,     pB.Begin + 1}}, // 1: [P, Q, Q]
            {{pA.Begin + 1, pB.Begin,     pB.Begin + 1}}, // 2: [P', Q, Q]
            {{pB.Begin + 1, pC.Begin,     pC.Begin + 1}}, // 3: [Q', R, R]
        }};
        for (const auto& layout : kLayouts) {
            for (size_t i = 1; i < layout.size(); ++i) {
                if (!(usedCtrs[layout[i - 1]] < usedCtrs[layout[i]])) {
                    std::fprintf(stderr, "layout is not strictly increasing\n");
                    return 2;
                }
            }
        }

        // hashed is read as hashedCatFeatures[featureIdx * docCount + i]: feature
        // major, indexed by categorical feature, not by position among the selected
        // CTRs. Size it by the real maximum index and give every (feature, doc) a
        // distinct value, so a lookup that confuses features or documents cannot
        // agree by accident.
        size_t maxCatFeature = 0;
        auto noteProjection = [&](const TFeatureCombination& proj) {
            for (const auto feature : proj.CatFeatures) {
                maxCatFeature = std::max(maxCatFeature, static_cast<size_t>(feature));
            }
        };
        for (const auto& layout : kLayouts) {
            for (const size_t index : layout) {
                noteProjection(usedCtrs[index].Base.Projection);
            }
        }
        const size_t kHashedFeatures = maxCatFeature + 1;
        TVector<ui8> binarized(kDocCount * kBuckets, 0);
        TVector<ui32> hashed(kDocCount * kHashedFeatures);
        for (size_t f = 0; f < kHashedFeatures; ++f) {
            for (size_t d = 0; d < kDocCount; ++d) {
                hashed[f * kDocCount + d] =
                    (ui32)((d * 2654435761u + (f + 1) * 40503u) % 9973u) + 1u;
            }
        }

        // One buffer, mutated in place: data() and size() never change. Declared
        // before the lambdas that fill it.
        TVector<TModelCtr> buffer(kBufferSize);
        const size_t addrBefore = (size_t)buffer.data();
        const size_t sizeBefore = buffer.size();

        auto hitsMisses = [&]() {
            size_t hits = 0;
            size_t misses = 0;
            TStaticCtrProvider::GetGroupingCacheStatsForDiagnostics(&hits, &misses);
            return std::make_pair(hits, misses);
        };
        auto fill = [&](const std::array<size_t, 3>& layout) {
            for (size_t i = 0; i < kBufferSize; ++i) {
                buffer[i] = usedCtrs[layout[i]];
            }
        };
        // The reference is a model loaded from disk, not ICtrProvider::Clone().
        // Clone copies CtrData only: CatFeatureIndex, FloatFeatureIndexes and
        // OneHotFeatureIndexes stay empty and SetupBinFeatureIndexes is not called,
        // so CalcCtrs on a clone would fail on CatFeatureIndex.at(). A freshly
        // loaded model is initialised, and its first call cannot be served from a
        // cache, which is what "uncached" has to mean here.
        auto uncachedReference = [&](const std::array<size_t, 3>& layout) {
            TFullModel fresh = ReadModel(opts.modelPath);
            TVector<TModelCtr> buf(kBufferSize);
            for (size_t i = 0; i < kBufferSize; ++i) {
                buf[i] = usedCtrs[layout[i]];
            }
            TVector<float> out(kBufferSize * kDocCount, -12345.0f);
            fresh.CtrProvider->CalcCtrs(buf, binarized, hashed, kDocCount, out);
            return out;
        };

        // Expected table. The projection SEQUENCE decides whether a cached grouping
        // is still valid, because the grouping is positional: cached ModelCtrs are
        // pointers into the caller's array at the same offsets, so a different CTR
        // inside the same projection still reads the right element.
        //
        //   0 [P,P,Q] first call      -> miss, cache empty
        //   0 [P,P,Q] unchanged        -> hit, same projections
        //   1 [P,Q,Q]                  -> miss, PPQ -> PQQ
        //   2 [P',Q,Q]                 -> HIT, projection sequence unchanged; the
        //                                   earlier version demanded a miss here and
        //                                   could only have passed by accident
        //   3 [Q',R,R]                 -> miss, PQQ -> QRR
        //   0 [P,P,Q] again           -> miss, QRR -> PPQ
        struct TStep {
            const char* Name;
            size_t Layout;
            bool WantHit;
        };
        const std::array<TStep, 6> kSteps = {{
            {"first_call", 0, false},
            {"unchanged", 0, true},
            {"new_sequence_1", 1, false},
            {"same_sequence_other_ctr", 2, true},
            {"new_sequence_2", 3, false},
            {"back_to_first", 0, false},
        }};

        int failures = 0;
        int checks = 0;
        std::vector<const char*> failedChecks;
        std::vector<size_t> observed;      // per step: hits*10 + misses
        std::vector<size_t> addresses;

        for (const auto& step : kSteps) {
            fill(kLayouts[step.Layout]);
            addresses.push_back((size_t)buffer.data());
            // Samples adjacent to the tested call, with nothing in between.
            const auto beforeStats = hitsMisses();
            TVector<float> value(kBufferSize * kDocCount, -12345.0f);
            model.CtrProvider->CalcCtrs(buffer, binarized, hashed, kDocCount, value);
            const auto afterStats = hitsMisses();
            const size_t hits = afterStats.first - beforeStats.first;
            const size_t misses = afterStats.second - beforeStats.second;
            observed.push_back(hits * 10 + misses);

            ++checks;
            const bool wantHit = step.WantHit;
            if (wantHit ? (hits != 1 || misses != 0) : (misses != 1 || hits != 0)) {
                ++failures;
                failedChecks.push_back(step.Name);
            }

            // Values, not only counters: the reference is computed after both
            // samples are taken, so it cannot move the numbers just checked.
            ++checks;
            if (value != uncachedReference(kLayouts[step.Layout])) {
                ++failures;
                failedChecks.push_back(step.Name);
            }
        }

        // A run in which the cache was never consulted says nothing about cache
        // behaviour. On the unified binary the preparation mode is a run-time
        // switch that defaults to Plain, where the cache is off by design, so the
        // counters stay at zero and every expectation would be reported as a
        // behavioural failure. That is a different diagnosis and gets its own
        // verdict code.
        size_t totalHits = 0;
        size_t totalMisses = 0;
        for (size_t o : observed) {
            totalHits += o / 10;
            totalMisses += o % 10;
        }
        const bool cacheExercised = (totalHits + totalMisses) > 0;

        const bool addressStable = std::all_of(
            addresses.begin(), addresses.end(),
            [&](size_t a) { return a == addrBefore; });
        ++checks;
        if (!addressStable || buffer.size() != sizeBefore) {
            ++failures;
            failedChecks.push_back("buffer_address_and_size_stable");
        }

        std::printf("{\n");
        std::printf("  \"cache_regression\": \"%s\",\n", opts.cacheRegression.c_str());
        std::printf("  \"buffer_address_stable\": %s,\n", addressStable ? "true" : "false");
        std::printf("  \"hashed_features\": %zu,\n", kHashedFeatures);
        std::printf("  \"hashed_layout\": \"feature-major: hashed[featureIdx * docCount + doc]\",\n");
        std::printf("  \"projections_used\": %zu,\n", ranges.size());
        std::printf("  \"reference\": \"freshly loaded TFullModel, not ICtrProvider::Clone\",\n");
        std::printf("  \"reference_limitations\": \"known-key and fallback paths are "
                    "NOT exercised: this fixture does not construct known keys or a "
                    "controlled fallback. ICtrProvider does expose AddCtrCalcerData, so "
                    "such a fixture is possible in principle; it is simply not built "
                    "here. Values are checked against a correctly initialised uncached "
                    "computation instead.\",\n");
        auto projectionIndex = [&](size_t ctrIndex) -> long {
            for (size_t r = 0; r < ranges.size(); ++r) {
                if (ctrIndex >= ranges[r].Begin && ctrIndex < ranges[r].End) {
                    return static_cast<long>(r);
                }
            }
            return -1;
        };
        std::printf("  \"expected_steps\": [");
        for (size_t i = 0; i < kSteps.size(); ++i) {
            std::printf("%s{\"step\": \"%s\", \"projections\": [%ld, %ld, %ld], "
                        "\"expect\": \"%s\"}",
                        i ? ", " : "",
                        kSteps[i].Name,
                        projectionIndex(kLayouts[kSteps[i].Layout][0]),
                        projectionIndex(kLayouts[kSteps[i].Layout][1]),
                        projectionIndex(kLayouts[kSteps[i].Layout][2]),
                        kSteps[i].WantHit ? "hit" : "miss");
        }
        std::printf("],\n");

        std::printf("  \"observed_hit_miss\": [");
        for (size_t i = 0; i < observed.size(); ++i) {
            std::printf("%s{\"step\": \"%s\", \"hits\": %zu, \"misses\": %zu}",
                        i ? ", " : "", kSteps[i].Name, observed[i] / 10, observed[i] % 10);
        }
        std::printf("],\n");
        std::printf("  \"cache_exercised\": %s,\n",
                    cacheExercised ? "true" : "false");
        std::printf("  \"cache_exercised\": %s,\n",
                    cacheExercised ? "true" : "false");
        std::printf("  \"checks\": %d,\n", checks);
        std::printf("  \"failures\": %d,\n", failures);
        std::printf("  \"failed_checks\": [");
        for (size_t i = 0; i < failedChecks.size(); ++i) {
            std::printf("%s\"%s\"", i ? ", " : "", failedChecks[i]);
        }
        std::printf("],\n");
        const char* verdict = !cacheExercised
            ? "CACHE_NOT_EXERCISED"
            : (failures == 0 ? "PASS" : "FAIL");
        std::printf("  \"verdict\": \"%s\"\n", verdict);
        std::printf("}\n");
        if (!cacheExercised) {
            std::fprintf(stderr,
                "the cache was never consulted: on a unified binary set "
                "STEP4_CTR_PREP_MODE=1 or 2, otherwise the preparation cache is off "
                "by design and this run says nothing about cache behaviour\n");
            return 3;
        }
        return failures == 0 ? 0 : 1;
    }

    if (!opts.lifecycleTest.empty()) {
        // Lifecycle of the per-thread grouping cache on long-lived threads that
        // repeatedly load and drop models, which is the pattern of a server that
        // reloads models without restarting. Checks three things:
        //  1. results stay bit-identical while provider addresses are recycled;
        //  2. the per-thread registry stays bounded and memory does not grow;
        //  3. an invalidation on one thread does not disturb another thread's
        //     cache, i.e. the caches are genuinely independent.
        TFullModel model = ReadModel(opts.modelPath);
        const auto& usedCtrs = model.ModelTrees->GetApplyData()->UsedModelCtrs;
        const size_t ctrCount = usedCtrs.size();
        const size_t kDocCount = 4;
        const size_t kBuckets = model.ModelTrees->GetEffectiveBinaryFeaturesBucketsCount();
        TVector<ui8> binarized(kDocCount * kBuckets, 0);
        TVector<ui32> hashed(kDocCount * ctrCount);
        for (size_t d = 0; d < kDocCount; ++d) {
            for (size_t c = 0; c < ctrCount; ++c) {
                hashed[d * ctrCount + c] = (ui32)((d * 2654435761u + c * 40503u) % 9973u);
            }
        }
        auto runOnce = [&](const TIntrusivePtr<ICtrProvider>& provider) {
            TVector<float> out(ctrCount * kDocCount);
            provider->CalcCtrs(usedCtrs, binarized, hashed, kDocCount, out);
            TFnv h;
            h.Update(out.data(), out.size() * sizeof(float));
            return h;
        };

        const TFnv reference = runOnce(model.CtrProvider);

        std::vector<uint64_t> failures(opts.lifecycleThreads, 0);
        std::vector<size_t> maxRegistry(opts.lifecycleThreads, 0);
        std::vector<size_t> distinctAddresses(opts.lifecycleThreads, 0);
        std::vector<long> rssStart(opts.lifecycleThreads, 0);
        std::vector<long> rssEnd(opts.lifecycleThreads, 0);
        std::vector<uint64_t> reusedAddress(opts.lifecycleThreads, 0);

        std::vector<std::thread> workers;
        for (int t = 0; t < opts.lifecycleThreads; ++t) {
            workers.emplace_back([&, t]() {
                std::vector<const void*> seen;
                const long rss0 = CurrentRssBytes();
                rssStart[t] = rss0;
                for (int it = 0; it < opts.lifecycleIterations; ++it) {
                    // Load and drop a model every iteration: providers are
                    // allocated and freed, so their addresses get recycled.
                    TFullModel fresh = ReadModel(opts.modelPath);
                    const void* addr = static_cast<const void*>(fresh.CtrProvider.get());
                    if (std::find(seen.begin(), seen.end(), addr) == seen.end()) {
                        seen.push_back(addr);
                    }
                    if (runOnce(fresh.CtrProvider).State != reference.State) {
                        ++failures[t];
                    }
                    maxRegistry[t] = std::max(
                        maxRegistry[t],
                        TStaticCtrProvider::GetCachedProviderCountForDiagnostics());
                    // Churn a second address so recycling is actually exercised.
                    {
                        TFullModel another = ReadModel(opts.modelPath);
                        if (runOnce(another.CtrProvider).State != reference.State) {
                            ++failures[t];
                        }
                    }
                }
                rssEnd[t] = CurrentRssBytes();
                distinctAddresses[t] = seen.size();
                reusedAddress[t] = (uint64_t)opts.lifecycleIterations - seen.size();
            });
        }
        for (auto& th : workers) { th.join(); }

        size_t totalFailures = 0;
        for (auto f : failures) { totalFailures += (size_t)f; }

        // Cross-thread invalidation: thread A reloads models (which invalidates
        // only A's own cache) while thread B keeps using its own loaded model.
        // B's results must stay correct, which they could not if the caches
        // were shared.
        {
            std::atomic<int> mismatches{0};
            std::atomic<bool> stop{false};
            std::thread churn([&]() {
                while (!stop.load()) {
                    TFullModel fresh = ReadModel(opts.modelPath);
                    if (runOnce(fresh.CtrProvider).State != reference.State) {
                        ++mismatches;
                    }
                }
            });
            TFullModel stable = ReadModel(opts.modelPath);
            for (int i = 0; i < 200; ++i) {
                if (runOnce(stable.CtrProvider).State != reference.State) {
                    ++mismatches;
                }
            }
            stop.store(true);
            churn.join();
            totalFailures += (size_t)mismatches.load();
        }

        std::printf("{\n");
        std::printf("  \"lifecycle_test\": \"%s\",\n", opts.lifecycleTest.c_str());
        std::printf("  \"threads\": %d,\n", opts.lifecycleThreads);
        std::printf("  \"iterations_per_thread\": %d,\n", opts.lifecycleIterations);
        std::printf("  \"models_loaded_per_thread\": %d,\n", opts.lifecycleIterations * 2);
        for (int t = 0; t < opts.lifecycleThreads; ++t) {
            // R4: RSS is a property of the process, not of a thread, so it is
        // reported once under an explicit name instead of per thread.
        std::printf("  \"thread_%d\": {\"max_registry_entries\": %zu, "
                        "\"distinct_provider_addresses\": %zu, \"address_reuses\": %llu, "
                        "\"mismatches\": %llu},\n",
                        t, maxRegistry[t], distinctAddresses[t],
                        (unsigned long long)reusedAddress[t],
                        (unsigned long long)failures[t]);
        }
        std::printf("  \"process_rss\": {\"note\": \"process-wide, not per thread\", "
                    "\"rss_start_mb\": %.2f, \"rss_end_mb\": %.2f, \"rss_growth_mb\": %.2f},\n",
                    rssStart[0] / 1048576.0, rssEnd[0] / 1048576.0,
                    (rssEnd[0] - rssStart[0]) / 1048576.0);
        std::printf("  \"total_mismatches\": %zu,\n", totalFailures);
        std::printf("  \"verdict\": \"%s\"\n", totalFailures == 0 ? "PASS" : "FAIL");
        std::printf("}\n");
        return totalFailures == 0 ? 0 : 1;
    }
#endif  // HARNESS_WITHOUT_CTR_CACHE

    if (!opts.raceTest.empty()) {
        // Concurrency check for the Step 4 cache. The cache is mutable provider
        // state, so a server handling parallel requests against one shared
        // provider is exactly the case that has to be proven safe.
        if (opts.modelPath.empty()) {
            std::fprintf(stderr, "--race-test requires --model\n");
            return 2;
        }
        TFullModel model = ReadModel(opts.modelPath);
        const auto& usedCtrs = model.ModelTrees->GetApplyData()->UsedModelCtrs;
        const size_t ctrCount = usedCtrs.size();
        const size_t kDocCount = 4;
        const size_t kBuckets = model.ModelTrees->GetEffectiveBinaryFeaturesBucketsCount();

        auto makeInputs = [&]() {
            TVector<ui8> binarized(kDocCount * kBuckets, 0);
            TVector<ui32> hashed(kDocCount * ctrCount);
            for (size_t d = 0; d < kDocCount; ++d) {
                for (size_t c = 0; c < ctrCount; ++c) {
                    hashed[d * ctrCount + c] = (ui32)((d * 2654435761u + c * 40503u) % 9973u);
                }
            }
            return std::make_pair(std::move(binarized), std::move(hashed));
        };
        auto runOnce = [&](const TIntrusivePtr<ICtrProvider>& provider,
                           const TConstArrayRef<TModelCtr>& ctrs,
                           const TVector<ui8>& binarized,
                           const TVector<ui32>& hashed) {
            TVector<float> out(ctrCount * kDocCount);
            provider->CalcCtrs(ctrs, binarized, hashed, kDocCount, out);
            TFnv h;
            h.Update(out.data(), out.size() * sizeof(float));
            return h;
        };

        auto [binarized, hashed] = makeInputs();

        // Reference: single-threaded, cold provider, so every thread can be
        // compared against a value no race could have produced.
        TFnv reference = runOnce(model.CtrProvider, usedCtrs, binarized, hashed);

        // Per-thread arguments. "shared" gives every thread its own array copy
        // (the validated-cache case), "shared-cold" has all threads present the
        // same array so the first fill races, "independent" gives each thread a
        // private provider.
        std::vector<TFullModel> ownModels(opts.raceThreads);
        std::vector<TVector<TModelCtr>> ownArrays(opts.raceThreads);
        for (int i = 0; i < opts.raceThreads; ++i) {
            ownArrays[i].assign(usedCtrs.begin(), usedCtrs.end());
            if (opts.raceTest == "independent") {
                ownModels[i] = ReadModel(opts.modelPath);
            }
        }

        // R4: an earlier version compared only the last result of each thread,
        // so a divergence that healed before the final iteration was invisible.
        // Every iteration is compared against the reference instead.
        std::vector<uint64_t> results(opts.raceThreads, 0);
        std::vector<uint64_t> divergenceCounts(opts.raceThreads, 0);
        std::thread::id mainThread = std::this_thread::get_id();
        std::vector<std::thread> workers;
        for (int i = 0; i < opts.raceThreads; ++i) {
            workers.emplace_back([&, i]() {
                const TIntrusivePtr<ICtrProvider>& provider =
                    (opts.raceTest == "independent") ? ownModels[i].CtrProvider : model.CtrProvider;
                TConstArrayRef<TModelCtr> ctrs =
                    (opts.raceTest == "shared") ? TConstArrayRef<TModelCtr>(ownArrays[i])
                                                : TConstArrayRef<TModelCtr>(usedCtrs);
                uint64_t last = 0;
                for (int it = 0; it < opts.raceIterations; ++it) {
                    last = runOnce(provider, ctrs, binarized, hashed).State;
                    if (last != reference.State) {
                        ++divergenceCounts[i];
                    }
                }
                results[i] = last;
            });
        }
        for (auto& t : workers) { t.join(); }

        int failures = 0;
        unsigned long long totalDivergent = 0;
        for (int i = 0; i < opts.raceThreads; ++i) {
            if (results[i] != reference.State) { ++failures; }
            failures += (int)divergenceCounts[i];
            totalDivergent += (unsigned long long)divergenceCounts[i];
        }
        std::printf("{\n");
        std::printf("  \"race_test\": \"%s\",\n", opts.raceTest.c_str());
        std::printf("  \"race_threads\": %d,\n", opts.raceThreads);
        std::printf("  \"race_iterations\": %d,\n", opts.raceIterations);
        std::printf("  \"reference\": \"");
        reference.Print();
        std::printf("\",\n");
        std::printf("  \"mismatching_threads\": %d,\n", failures);
        // Previously hardcoded to 0, so a run with divergences printed zero and
        // could be read as a clean pass. The per-thread counts below were the
        // only honest source; the total is now their sum.
        std::printf("  \"divergent_iterations_total\": %llu,\n", totalDivergent);
        for (int i = 0; i < opts.raceThreads; ++i) {
            std::printf("  \"thread_%d_divergent_iterations\": %llu,\n", i,
                        (unsigned long long)divergenceCounts[i]);
        }
        std::printf("  \"verdict\": \"%s\"\n", failures == 0 ? "PASS" : "FAIL");
        std::printf("}\n");
        return failures == 0 ? 0 : 1;
    }

    if (opts.modelPath.empty() || opts.poolPath.empty() || opts.cdPath.empty()) {
        std::fprintf(stderr, "usage: %s --model M --pool P --cd C"
            " [--block-size N] [--repetitions N] [--threads N]\n", argv[0]);
        return 2;
    }

    // Set by the serve test; the process must fail if concurrent requests
    // against one shared provider did not reproduce the reference.
    std::atomic<int> serveFailed{0};

    auto queue = CreateThreadPool(1);
    NThreading::TFuture<void> future = NThreading::Async([&]() {
        TFullModel model = ReadModel(opts.modelPath);

        if (opts.threads > 1) {
            NPar::LocalExecutor().RunAdditionalThreads(opts.threads - 1);
        }

        NCatboostOptions::TColumnarPoolFormatParams cdParams;
        cdParams.CdFilePath = NCB::TPathWithScheme(opts.cdPath, "dsv");
        TDataProviderPtr dataset = NCB::ReadDataset(
            /*taskType*/Nothing(),
            NCB::TPathWithScheme(opts.poolPath, "dsv"),
            NCB::TPathWithScheme(), NCB::TPathWithScheme(), NCB::TPathWithScheme(),
            NCB::TPathWithScheme(), NCB::TPathWithScheme(), NCB::TPathWithScheme(),
            NCB::TPathWithScheme(),
            cdParams, TVector<ui32>(), NCB::EObjectsOrder::Undefined,
            NSystemInfo::CachedNumberOfCpus(), true, false, false, Nothing());

        THolder<NCB::IFeaturesBlockIterator> blockIt =
            NCB::CreateFeaturesBlockIterator(model, *(dataset->ObjectsData), 0, dataset->GetObjectCount());
        NCB::TRawFeaturesBlockIterator* raw = dynamic_cast<NCB::TRawFeaturesBlockIterator*>(blockIt.Get());
        CB_ENSURE(raw, "only raw pools are supported by this harness");
        raw->NextBlock((size_t)dataset->GetObjectCount());

        const auto& layout = *dataset->MetaInfo.FeaturesLayout;
        auto featurePtr = [&](ui32 flatIdx) -> const float* {
            switch (layout.GetExternalFeatureType(flatIdx)) {
                case EFeatureType::Float: return raw->GetFloatValues()[flatIdx].data();
                case EFeatureType::Categorical: return (const float*)raw->GetCatValues()[flatIdx].data();
                default: CB_ENSURE(false, "unsupported column type");
            }
        };

        const size_t docCount = dataset->GetObjectCount();
        const size_t size = Min<size_t>(opts.blockSize, docCount);
        const size_t factorCount = model.ModelTrees->GetFlatFeatureVectorExpectedSize();

        // Built once, before the measured loop: the same features-first layout
        // on which the reuse-ctr-buckets win was originally measured.
        TVector<TConstArrayRef<float>> factors(factorCount);
        for (size_t i = 0; i < factorCount; ++i) {
            factors[i] = MakeArrayRef<const float>(featurePtr((ui32)i), size);
        }

        auto evaluator = NModelEvaluation::CreateEvaluator(EFormulaEvaluatorType::CPU, model);
        TVector<double> results(factorCount ? size : 0);

        // S2: the full path from raw categorical strings. Every repetition reads
        // the DSV and rebuilds the Pool, so the categorical hashing path runs
        // again; the two phases are timed separately and `full_ms` is their sum,
        // not a third measurement. A Pool built once and reused would measure S1
        // twice and hide whatever D changes in feature construction.
        NCatboostOptions::TColumnarPoolFormatParams fullPathCd;
        fullPathCd.CdFilePath = NCB::TPathWithScheme(opts.cdPath, "dsv");
        auto buildPool = [&]() {
            return NCB::ReadDataset(
                /*taskType*/Nothing(),
                NCB::TPathWithScheme(opts.poolPath, "dsv"),
                NCB::TPathWithScheme(), NCB::TPathWithScheme(), NCB::TPathWithScheme(),
                NCB::TPathWithScheme(), NCB::TPathWithScheme(), NCB::TPathWithScheme(),
                NCB::TPathWithScheme(),
                fullPathCd, TVector<ui32>(), NCB::EObjectsOrder::Undefined,
                NSystemInfo::CachedNumberOfCpus(), true, false, false, Nothing());
        };
        auto factorsOf = [&](const TDataProviderPtr& pool) {
            THolder<NCB::IFeaturesBlockIterator> it =
                NCB::CreateFeaturesBlockIterator(model, *(pool->ObjectsData), 0,
                                                 pool->GetObjectCount());
            NCB::TRawFeaturesBlockIterator* r =
                dynamic_cast<NCB::TRawFeaturesBlockIterator*>(it.Get());
            CB_ENSURE(r, "only raw pools are supported by this harness");
            r->NextBlock((size_t)pool->GetObjectCount());
            const auto& lay = *pool->MetaInfo.FeaturesLayout;
            const size_t take = Min<size_t>(size, (size_t)pool->GetObjectCount());
            auto ptr = [&](ui32 flatIdx) -> const float* {
                switch (lay.GetExternalFeatureType(flatIdx)) {
                    case EFeatureType::Float: return r->GetFloatValues()[flatIdx].data();
                    case EFeatureType::Categorical:
                        return (const float*)r->GetCatValues()[flatIdx].data();
                    default: CB_ENSURE(false, "unsupported column type");
                }
            };
            TVector<TConstArrayRef<float>> out(factorCount);
            for (size_t i = 0; i < factorCount; ++i) {
                out[i] = MakeArrayRef<const float>(ptr((ui32)i), take);
            }
            return out;
        };

        if (opts.fullPath) {
            // Two full turns of warm-up, so the first timed repetition does not
            // pay for the first allocation of a Pool.
            for (int i = 0; i < 2; ++i) {
                TDataProviderPtr warmPool = buildPool();
                evaluator->CalcFlatTransposed(factorsOf(warmPool), results);
            }
        } else {
            for (int i = 0; i < 5; ++i) {
                evaluator->CalcFlatTransposed(factors, results);
            }
        }

        // Whole-dataset identity. A single block covers only the first
        // min(blockSize, objectCount) rows, which is not enough to claim the
        // variants agree on the data: every row is hashed in order, so the digest
        // covers the entire prediction vector, and the per-chunk digests say how it
        // was cut. The evaluator and the feature layout are the same objects the
        // measured loop uses.
        TFnv fullHash;
        size_t rowsCovered = 0;
        size_t chunkCount = 0;
        std::vector<std::string> chunkHashes;
        if (opts.fullDataset) {
            const size_t chunk = std::max<size_t>(1, (size_t)opts.blockSize);
            for (size_t from = 0; from < docCount; from += chunk) {
                const size_t take = std::min(chunk, docCount - from);
                TVector<TConstArrayRef<float>> chunkFactors(factorCount);
                for (size_t i = 0; i < factorCount; ++i) {
                    const float* base = featurePtr((ui32)i);
                    chunkFactors[i] = MakeArrayRef<const float>(base + from, take);
                }
                TVector<double> chunkResults(factorCount ? take : 0);
                evaluator->CalcFlatTransposed(chunkFactors, chunkResults);
                fullHash.Update(chunkResults.data(), chunkResults.size() * sizeof(double));
                TFnv one;
                one.Update(chunkResults.data(), chunkResults.size() * sizeof(double));
                std::string text;
                one.Print(&text);
                chunkHashes.push_back(text);
                rowsCovered += take;
                ++chunkCount;
            }
        }

        // Reference prediction for the equivalence check: one call on the same
        // block, hashed bitwise so variants can be compared exactly.
        TFnv reference;
        reference.Update(results.data(), results.size() * sizeof(double));

#ifdef HARNESS_HAS_PHASE_PROFILE
        // Reset the accumulated counters after the warm-up, so only the
        // measured region is reported.
        NCB::NPhaseProfile::Local().Reset();
        const bool profileEnabled = NCB::NPhaseProfile::Enabled();
#else
        const bool profileEnabled = false;
#endif

        TVector<double> perRep;
        perRep.reserve(opts.repetitions);
        TVector<double> perRepPool;
        TVector<double> perRepPredict;
        perRepPool.reserve(opts.repetitions);
        perRepPredict.reserve(opts.repetitions);
        double total = 0.0;
        for (size_t r = 0; r < opts.repetitions; ++r) {
            if (opts.fullPath) {
                THPTimer poolTimer;
                TDataProviderPtr fresh = buildPool();
                TVector<TConstArrayRef<float>> freshFactors = factorsOf(fresh);
                const double poolSeconds = poolTimer.Passed();
                THPTimer predictTimer;
                evaluator->CalcFlatTransposed(freshFactors, results);
                const double predictSeconds = predictTimer.Passed();
                perRepPool.push_back(poolSeconds);
                perRepPredict.push_back(predictSeconds);
                perRep.push_back(poolSeconds + predictSeconds);
            } else {
                THPTimer one;
                evaluator->CalcFlatTransposed(factors, results);
                perRep.push_back(one.Passed());
            }
            total += perRep.back();
        }

        auto sorted = perRep;
        std::sort(sorted.begin(), sorted.end());
        const double median = sorted[sorted.size() / 2];
        const size_t edge = std::max<size_t>(1, opts.repetitions / 10);
        // The vector is a parameter: an earlier version closed over `perRep`, so
        // `per_rep_pool_ms` and `per_rep_predict_ms` were both reporting the total
        // and the two phases could not be told apart in the output at all.
        auto mean = [&](const TVector<double>& v, size_t from, size_t to) {
            double acc = 0.0;
            for (size_t i = from; i < to; ++i) { acc += v[i]; }
            return acc / (to - from);
        };

        std::printf("{\n");
        std::printf("  \"block_size\": %zu,\n", size);
        // Both row counts are reported so a consumer can check that a full-path
        // number really describes a request of the predicted size. `block_size`
        // is the predicted block; `pool_rows` is what the Pool was built from.
        std::printf("  \"predicted_rows\": %zu,\n", size);
        std::printf("  \"pool_rows\": %zu,\n", (size_t)docCount);
        std::printf("  \"repetitions\": %zu,\n", opts.repetitions);
        std::printf("  \"threads\": %d,\n", opts.threads);
        std::printf("  \"total_ms\": %.6f,\n", total * 1000.0);
        std::printf("  \"per_rep_ms\": {\"median\": %.6f, \"min\": %.6f, "
                    "\"first_decile\": %.6f, \"last_decile\": %.6f},\n",
                    median * 1000.0, sorted.front() * 1000.0,
                    mean(perRep, 0, edge) * 1000.0,
                    mean(perRep, perRep.size() - edge, perRep.size()) * 1000.0);
        std::printf("  \"profile_enabled\": %s,\n", profileEnabled ? "true" : "false");
        if (opts.fullPath) {
            // Same estimator as `per_rep_ms`, applied to each phase separately, so
            // a reader never has to subtract two totals to recover one phase.
            auto report = [&](const char* name, const TVector<double>& v) {
                auto sv = v;
                std::sort(sv.begin(), sv.end());
                const double med = sv[sv.size() / 2];
                std::printf("  \"%s\": {\"median\": %.6f, \"min\": %.6f, "
                            "\"first_decile\": %.6f, \"last_decile\": %.6f},\n",
                            name, med * 1000.0, sv.front() * 1000.0,
                            mean(v, 0, edge) * 1000.0,
                            mean(v, v.size() - edge, v.size()) * 1000.0);
            };
            std::printf("  \"scenario\": \"full_path\",\n");
            report("per_rep_pool_ms", perRepPool);
            report("per_rep_predict_ms", perRepPredict);
        } else {
            std::printf("  \"scenario\": \"predict\",\n");
        }
#ifdef HARNESS_HAS_PHASE_PROFILE
        if (profileEnabled) {
            const auto& prof = NCB::NPhaseProfile::Snapshot();
            auto pct = [&](double v) {
                return total > 0 ? 100.0 * v / total : 0.0;
            };
            std::printf("  \"phases\": {");
            std::printf("\"feature_prep\": {\"ms\": %.4f, \"pct\": %.2f}, ", prof.FeaturePrep * 1000.0, pct(prof.FeaturePrep));
            std::printf("\"calc_ctrs\": {\"ms\": %.4f, \"pct\": %.2f}, ", prof.CalcCtrs * 1000.0, pct(prof.CalcCtrs));
            std::printf("\"ctr_binarize\": {\"ms\": %.4f, \"pct\": %.2f}, ", prof.CtrBinarize * 1000.0, pct(prof.CtrBinarize));
            std::printf("\"tree_traversal\": {\"ms\": %.4f, \"pct\": %.2f}", prof.TreeTraversal * 1000.0, pct(prof.TreeTraversal));
            std::printf("}, \"covered_pct\": %.2f", total > 0 ? 100.0 * prof.Sum() / total : 0.0);
            std::printf(", \"ctr_calls\": %lld, \"lookup_loops\": %lld, \"lookup_docs\": %lld,\n",
                        prof.CtrCalls, prof.LookupLoops, prof.LookupDocs);
        } else {
            std::printf("  \"phases\": null,\n");
        }
#else
        std::printf("  \"phases\": null,\n");
#endif
        std::printf("  \"pred_hash\": \"");
        reference.Print();
        std::printf("\"");
        std::printf(",\n");
        if (opts.fullDataset) {
            std::printf("  \"full_dataset\": {\"rows\": %zu, \"chunks\": %zu, \"chunk_rows\": %zu, ",
                        rowsCovered, chunkCount, (size_t)opts.blockSize);
            std::printf("\"pred_hash_full\": \"");
            fullHash.Print();
            std::printf("\", \"chunk_hashes\": [");
            for (size_t i = 0; i < chunkHashes.size(); ++i) {
                std::printf("%s\"%s\"", i ? ", " : "", chunkHashes[i].c_str());
            }
            std::printf("]},\n");
        }

        // --- Concurrency of one shared provider under parallel requests --------
        // The checks above drive the provider directly. This one serves the
        // production pattern: one loaded model whose CtrProvider is shared by
        // several request threads, each running a whole predict, while other
        // threads load and drop models at the same time. Every result is compared
        // bitwise against a single-threaded reference computed beforehand.
        //
        // A race that produced a wrong CTR would change the prediction, and a
        // cache that returned a stale grouping would too, so a bitwise match here
        // is evidence of consistency. It is not a proof of the absence of races:
        // a benign-looking interleaving can be missed, and a data race can exist
        // on a path this fixture does not reach. TSan is the instrument for that.
        if (opts.runServeTest) {
            // Reference first, single-threaded, so no thread can influence it.
            auto refEvaluator = NModelEvaluation::CreateEvaluator(
                EFormulaEvaluatorType::CPU, model);
            TVector<double> refResults(factorCount ? size : 0);
            refEvaluator->CalcFlatTransposed(factors, refResults);
            TFnv reference;
            reference.Update(refResults.data(), refResults.size() * sizeof(double));

            // Per-thread input copies. Sharing the input arrays between threads
            // would be a race in the fixture itself, and its report would then
            // say nothing about the provider.
            std::vector<TVector<TConstArrayRef<float>>> threadFactors(opts.serveThreads);
            std::vector<std::vector<float>> threadBacking(opts.serveThreads);
            for (int t = 0; t < opts.serveThreads; ++t) {
                threadBacking[t].resize(factorCount * size);
                for (size_t i = 0; i < factorCount; ++i) {
                    std::memcpy(&threadBacking[t][i * size], featurePtr((ui32)i),
                                size * sizeof(float));
                    threadFactors[t].push_back(
                        MakeArrayRef<const float>(&threadBacking[t][i * size], size));
                }
            }

            std::atomic<bool> stopLoaders{false};
            std::atomic<unsigned long long> loads{0};
            std::atomic<int> loaderFailures{0};
            std::vector<uint64_t> serveBad(opts.serveThreads, 0);
            std::vector<uint64_t> serveLast(opts.serveThreads, 0);

            std::vector<std::thread> all;
            for (int t = 0; t < opts.serveThreads; ++t) {
                all.emplace_back([&, t]() {
                    // The evaluator is built from the SHARED model, so all these
                    // evaluators share one CtrProvider and one cache.
                    auto evaluator =
                        NModelEvaluation::CreateEvaluator(EFormulaEvaluatorType::CPU, model);
                    TVector<double> out(factorCount ? size : 0);
                    for (int it = 0; it < opts.serveIterations; ++it) {
                        evaluator->CalcFlatTransposed(threadFactors[t], out);
                        TFnv h;
                        h.Update(out.data(), out.size() * sizeof(double));
                        serveLast[t] = h.State;
                        if (h.State != reference.State) {
                            ++serveBad[t];
                        }
                    }
                });
            }
            // Model load and destroy while the requests above are in flight.
            for (int l = 0; l < opts.serveLoaders; ++l) {
                all.emplace_back([&]() {
                    try {
                        for (int it = 0; it < opts.serveLoadIters && !stopLoaders; ++it) {
                            TFullModel fresh = ReadModel(opts.modelPath);
                            // Touch the provider so a load that skips it is not
                            // counted as coverage of the load path.
                            volatile bool hasProvider = fresh.CtrProvider != nullptr;
                            (void)hasProvider;
                            loads.fetch_add(1, std::memory_order_relaxed);
                        }
                    } catch (...) {
                        loaderFailures.fetch_add(1);
                    }
                });
            }
            for (auto& th : all) { th.join(); }

            unsigned long long badTotal = 0;
            for (int t = 0; t < opts.serveThreads; ++t) {
                badTotal += serveBad[t];
                if (serveLast[t] != reference.State && serveBad[t] == 0) {
                    badTotal += 1;
                }
            }

            // Power check. A counter that reads zero is only evidence if it can be
            // shown to fire: one perturbed input must be reported as a mismatch by
            // the same comparison the run above relies on. If this reports zero,
            // the zeros in the table mean the check is blind, not that the code is
            // clean.
            bool powerDetected = false;
            {
                TVector<TConstArrayRef<float>> perturbed = threadFactors[0];
                if (threadBacking[0].empty()) {
                    CB_ENSURE(!threadFactors[0].empty(), "no factors to perturb");
                }
                std::vector<float> copy(threadBacking[0]);
                copy[0] = std::nextafter(copy[0], 1.0e30f);
                perturbed.clear();
                for (size_t i = 0; i < factorCount; ++i) {
                    perturbed.push_back(
                        MakeArrayRef<const float>(&copy[i * size], size));
                }
                auto probe =
                    NModelEvaluation::CreateEvaluator(EFormulaEvaluatorType::CPU, model);
                TVector<double> probeOut(factorCount ? size : 0);
                probe->CalcFlatTransposed(perturbed, probeOut);
                TFnv h;
                h.Update(probeOut.data(), probeOut.size() * sizeof(double));
                powerDetected = (h.State != reference.State);
            }

            std::printf("  \"serve_test\": {\n");
            std::printf("    \"threads\": %d, \"iterations\": %d,\n",
                        opts.serveThreads, opts.serveIterations);
            std::printf("    \"loaders\": %d, \"model_loads\": %llu, \"loader_failures\": %d,\n",
                        opts.serveLoaders, (unsigned long long)loads.load(), loaderFailures.load());
            std::printf("    \"requests\": %llu,\n",
                        (unsigned long long)opts.serveThreads * opts.serveIterations);
            std::printf("    \"reference\": \"");
            reference.Print();
            std::printf("\",\n");
            std::printf("    \"mismatching_requests\": %llu,\n", badTotal);
            std::printf("    \"power_check_detects_change\": %s,\n",
                        powerDetected ? "true" : "false");
            std::printf("    \"per_thread_mismatches\": [");
            for (int t = 0; t < opts.serveThreads; ++t) {
                std::printf("%s%llu", t ? ", " : "", (unsigned long long)serveBad[t]);
            }
            std::printf("],\n");
            const bool serveOk = (badTotal == 0) && powerDetected;
            std::printf("    \"verdict\": \"%s\"\n", serveOk ? "PASS" : "FAIL");
            std::printf("  },\n");
            if (!serveOk) {
                serveFailed.store(1);
            }
        }

        // --- Lifecycle self-test of the Step 4 cache -------------------------
        // The cache is keyed by the identity of the caller-provided CTR array and
        // validated on every use. These calls drive one provider through
        // changing arguments and a fresh provider through a model reload, which
        // is where a stale-pointer bug would show up.
        {
            auto provider = model.CtrProvider;
            const auto& usedCtrs = model.ModelTrees->GetApplyData()->UsedModelCtrs;
            const size_t ctrCount = usedCtrs.size();
            const size_t kDocCount = 4;
            const size_t kBuckets = model.ModelTrees->GetEffectiveBinaryFeaturesBucketsCount();

            // A model with no CTR has no bucket table and no projections, so the
            // check below has nothing to exercise and CalcCtrs on empty input is
            // not a supported call. Such models are exactly the overhead control
            // in the cross-dataset stage, so they have to run, not crash: the
            // prediction itself already completed above.
            if (ctrCount == 0 || kBuckets == 0) {
                // No trailing comma: this is the last member of the object, and
                // an earlier version left the document unterminated here.
                std::printf("  \"selftest\": {\"skipped\": true, \"reason\": "
                            "\"model has no CTR (%s, %s)\"}\n",
                            ctrCount == 0 ? "ctr_features=0" : "buckets=0",
                            ctrCount == 0 ? "no grouping cache is exercised"
                                          : "no bucket table");
            } else {
            TVector<ui8> binarized(kDocCount * kBuckets, 0);
            TVector<ui32> hashed(kDocCount * usedCtrs.size(), 0);
            // Distinct values per document so a stale bucket lookup would show.
            for (size_t d = 0; d < kDocCount; ++d) {
                for (size_t c = 0; c < usedCtrs.size(); ++c) {
                    hashed[d * usedCtrs.size() + c] = (ui32)((d * 2654435761u + c * 40503u) % 9973u);
                }
            }
            TVector<float> out(ctrCount * kDocCount);

            auto calcHash = [&](TConstArrayRef<TModelCtr> ctrs) {
                std::fill(out.begin(), out.end(), 0.f);
                provider->CalcCtrs(ctrs, binarized, hashed, kDocCount, out);
                TFnv h;
                h.Update(out.data(), out.size() * sizeof(float));
                return h;
            };

            // 1) Full set, first call: populates the cache.
            auto full1 = calcHash(usedCtrs);
            // 2) A different, shorter array on the SAME provider must not reuse it.
            TConstArrayRef<TModelCtr> subset(usedCtrs.data(), ctrCount / 2);
            auto half = calcHash(subset);
            // 3) Full set again: must reproduce the first result exactly.
            auto full2 = calcHash(usedCtrs);
            // 4) A separate array with identical content: grouping depends only
            //    on the Projection sequence, so the result must match.
            TVector<TModelCtr> copy(usedCtrs.begin(), usedCtrs.end());
            auto fullCopy = calcHash(copy);
            // 5) A freshly loaded model and provider must agree with the first.
            TFullModel reloaded = ReadModel(opts.modelPath);
            TFnv reloadedHash;
            {
                TVector<float> out2(ctrCount * kDocCount);
                reloaded.CtrProvider->CalcCtrs(
                    reloaded.ModelTrees->GetApplyData()->UsedModelCtrs,
                    binarized, hashed, kDocCount, out2);
                reloadedHash.Update(out2.data(), out2.size() * sizeof(float));
            }

            std::printf("  \"selftest\": {");
            std::printf("\"full_first\": \""); full1.Print();
            std::printf("\", \"subset_differs\": %s", (full1.State == half.State) ? "false" : "true");
            std::printf(", \"full_again_matches\": %s", (full1.State == full2.State) ? "true" : "false");
            std::printf(", \"copied_array_matches\": %s", (full1.State == fullCopy.State) ? "true" : "false");
            std::printf(", \"reloaded_model_matches\": %s", (full1.State == reloadedHash.State) ? "true" : "false");
            // 6) A cloned provider: copying TFullModel clones the provider, so
            //    the clone must start from an empty cache and still agree.
            TFnv clonedHash;
            {
                TFullModel cloned = model;
                TVector<float> out3(ctrCount * kDocCount);
                cloned.CtrProvider->CalcCtrs(
                    cloned.ModelTrees->GetApplyData()->UsedModelCtrs,
                    binarized, hashed, kDocCount, out3);
                clonedHash.Update(out3.data(), out3.size() * sizeof(float));
            }
            std::printf(", \"cloned_provider_matches\": %s", (full1.State == clonedHash.State) ? "true" : "false");
            std::printf("}\n");
            }
        }
        std::printf("}\n");
    }, *queue);
    future.GetValueSync();
    return serveFailed.load() != 0 ? 1 : 0;
} catch (...) {
    std::fprintf(stderr, "%s\n", CurrentExceptionMessage().c_str());
    return 1;
}
