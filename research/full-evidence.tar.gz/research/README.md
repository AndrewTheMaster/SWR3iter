# SWR3iter: CPU CTR inference review

This directory documents both a fresh local recheck on CatBoost `master`
(`d694ce0f`) and the earlier experiments on v1.2.10. The implementation
commits are separate from this evidence commit so that each can be reviewed on
its own. The upstream `master` baseline contains none of these research files.

The project is about CPU inference with categorical features. It does not change
model training, the set of CTR features, or prediction values. The two changes
remove repeated work in `TStaticCtrProvider::CalcCtrs`:

1. Reuse bucket indices for adjacent CTRs backed by the same table.
2. Reuse the projection grouping across `CalcCtrs` calls when the caller's CTR
   array has the same address, length, and **exact projection sequence**. The
   grouping cache is thread-local and bounded to eight provider entries.

## Current-master local recheck: batch 4096, two threads

`A` is stock CatBoost `d694ce0f`, and `C` includes both changes. These are
fresh binaries built from the same source revision and CMake configuration on
macOS 26.6 / Apple M4 Pro / Apple clang 21. The measure is `predict` on a
prepared Pool, 200 consecutive repetitions per process. The estimator is the
mean of the final 20 repetitions **in execution order**. Each model has nine
paired sessions, with order alternating between A/C and C/A. The point estimate
is the median of nine paired percent changes; the 95% interval bootstraps that
same median by resampling entire pairs 20,000 times (seed 20261003).

| Model and held-out data | A, ms | C, ms | C/A | 95% interval | Winning pairs |
|---|---:|---:|---:|---:|---:|
| Amazon Employee Access | 2.3918 | 1.8970 | **−20.76%** | [−21.69%, −19.73%] | 9/9 |
| KDD Cup 2009 churn | 7.0803 | 6.3595 | **−9.38%** | [−12.72%, −8.17%] | 9/9 |
| Criteo Click Logs sample | 9.4271 | 8.7991 | **−6.12%** | [−8.19%, −5.53%] | 9/9 |

![Fresh current-master paired latency changes](current-master-20261003/latency-4096-2threads.svg)

Full-holdout prediction hashes matched between A and C before timing: 6,554
Amazon, 12,500 KDD and 757,695 Criteo rows. The exact cache hit/miss
regression, known-key/fallback fixture, and 4-thread shared-provider check all
returned `PASS`; the CatBoost `model_ut` target built and ran with exit 0 (35
`[good]` test lines). Hash matching is strong empirical evidence, but the
64-bit hash alone is not a formal proof of bitwise equality. This run did not
use ThreadSanitizer and does not establish a Linux x86-64 speedup.

The compact raw observations, hashes, protocol, harness source and local build
patch are in [`current-master-20261003`](current-master-20261003/README.md).

## Earlier v1.2.10 result at batch 4096, two threads

Here, `A` is unmodified CatBoost v1.2.10 at commit `b1bd2a6d7721`; `C` includes both
changes. All numbers below measure `predict` on an already built Pool. The point
estimate is the median of nine paired per-session changes; the interval is a
95% bootstrap interval for that same median. Negative means faster.

| Model and independent data | A, ms | C, ms | C/A | 95% interval | Winning sessions |
|---|---:|---:|---:|---:|---:|
| Amazon Employee Access | 2.2333 | 1.8281 | **−18.22%** | [−18.78%, −17.30%] | 9/9 |
| KDD Cup 2009 churn | 7.8674 | 7.4324 | **−5.53%** | [−6.82%, −4.28%] | 9/9 |
| Criteo Click Logs sample | 10.7806 | 10.3000 | **−4.77%** | [−6.12%, −3.53%] | 9/9 |

![Paired changes in CPU prediction latency](figures/latency-4096-2threads.svg)

On KDD and Criteo, 15 of 16 CTR-model `predict` cells across batch sizes
1/128/1024/4096 and one/two threads had an interval excluding zero. The two
new models were trained independently on their respective datasets; the three
earlier Amazon model structures were all trained on Amazon and are not counted
as independent datasets. Numerical-only models with no CTR acted as negative
controls. The complete matrix, including weak and negative results, is in
[`artifacts/cross-dataset-report.json`](artifacts/cross-dataset-report.json).

Before timing, `A=B=C` prediction hashes matched across the full holdout:
6,554 Amazon rows, 12,500 KDD rows, and 757,695 Criteo rows. The KDD and Criteo
holdouts included category values unseen in training. This is an empirical
correctness check, not a substitute for upstream unit tests.

## Scope and limitations

- The historical timings are from a different CatBoost revision, v1.2.10;
  they must not be pooled with the fresh `d694ce0f` series or read as the
  result of a controlled comparison between revisions.
- The batch-1 results use 200 consecutive calls in one process and therefore
  exercise a warm cache. A cold, one-call-per-model-load workload was not timed.
- The full path that builds a Pool from DSV input often shows a smaller effect;
  these changes target prediction after Pool construction. KDD and Criteo use
  held-out subsets, not every row in their source datasets.
- The two data-dependent mechanisms contribute differently across models.
  No universal speedup percentage is claimed. The experimental `cat-hash-cache`
  change is excluded because its earlier gain did not reproduce on the DSV path.
- No Linux x86-64 benchmark is included. That is follow-up work before an
  upstream cross-platform performance claim.

## Inspect and reproduce the historical evidence

| Artifact | Purpose |
|---|---|
| [`artifacts/amazon-protocol.md`](artifacts/amazon-protocol.md) | Predeclared confirmation procedure |
| [`artifacts/amazon-report.json`](artifacts/amazon-report.json) | Nine paired sessions and interval |
| [`artifacts/amazon-raw.json.gz`](artifacts/amazon-raw.json.gz) | Original raw session records, gzip compressed |
| [`artifacts/cross-dataset-protocol.md`](artifacts/cross-dataset-protocol.md) | KDD/Criteo sampling and benchmark protocol |
| [`artifacts/cross-dataset-report.json`](artifacts/cross-dataset-report.json) | All 64 reported cells, including no-CTR controls |
| [`artifacts/cross-dataset-raw.json.gz`](artifacts/cross-dataset-raw.json.gz) | Original 1,728 raw session records, gzip compressed |
| [`artifacts/SHA256SUMS`](artifacts/SHA256SUMS) | Verifiable SHA-256 for committed evidence files |
| [`artifacts/ORIGINAL_RAW_SHA256.md`](artifacts/ORIGINAL_RAW_SHA256.md) | SHA-256 of the uncompressed historical originals |

`python3 research/plot.py` regenerates the figure from the committed report
JSON files (requires matplotlib). The uncompressed raw files, models, binaries,
and full experimental scripts remain in the separate
[`SRW2iter`](https://github.com/AndrewTheMaster/SRW2iter) research checkout;
large datasets and binaries are not copied into this branch. Paths inside raw
records refer to that original checkout and are preserved as provenance, not as
portable commands.

For contribution to CatBoost itself, the two implementation commits should be
proposed separately from this historical evidence commit and accompanied by
upstream regression tests. The CatBoost contribution guide asks contributors to
discuss the change in an issue before opening an upstream PR.
