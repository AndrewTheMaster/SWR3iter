#!/usr/bin/env python3
from __future__ import annotations
import csv, json, re
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
ROOT=Path(__file__).resolve().parent.parent
NIR=ROOT/'results/nir'
FIG=ROOT/'figures'; FIG.mkdir(exist_ok=True)

def load(p): return json.loads(Path(p).read_text())
def metric(p):
 rows=list(csv.reader(Path(p).open(),delimiter='\t')); return {k:float(v) for k,v in zip(rows[0],rows[-1])}
def peak(p):
 m=re.search(r'(\d+)\s+maximum resident set size',Path(p).read_text()); return int(m.group(1))/1e9 if m else None
def train_time(p):
 m=re.search(r'([\d.,]+) real',Path(p).read_text()); return float(m.group(1).replace(',','.')) if m else None

def main():
    models=[
        ('criteo_max1','Criteo_x1 max_ctr_complexity=1',ROOT/'results/nir/criteo_max1'),
        ('criteo_max2','Criteo_x1 max_ctr_complexity=2',ROOT/'results/nir/criteo_max2'),
        ('criteo_max4','Criteo_x1 max_ctr_complexity=4',ROOT/'results/criteo_x1/cache_model'),
        ('avazu_max2','Avazu_x1 max_ctr_complexity=2',ROOT/'results/nir/avazu_max2'),
    ]
    inf={x['name']:x for x in load(NIR/'inference/records.json')}
    rows=[]
    for key,label,d in models:
        s=load(d/'structure.json')[0]; q=metric(d/'metrics.tsv')
        rows.append({'key':key,'label':label,'structure':s,'quality':q,
                     'train_s':train_time(d/'time.log'),'peak_gb':peak(d/'time.log'),
                     'model_gb':(d/'model.cbm').stat().st_size/1e9,
                     'inf':inf[key]})
    # figure: effect with CI
    labels=[r['label'].replace('Criteo_x1 ','Criteo ').replace('Avazu_x1 ','Avazu ') for r in rows]
    vals=np.array([r['inf']['median_paired_change_pct'] for r in rows])
    cis=np.array([r['inf']['median_paired_change_ci95_pct'] for r in rows])
    err=np.vstack([vals-cis[:,0],cis[:,1]-vals])
    fig,ax=plt.subplots(figsize=(10,5))
    colors=['#08519c','#4292c6','#9ecae1','#d62728']
    ax.bar(labels,vals,yerr=err,capsize=4,color=colors)
    ax.axhline(0,color='black',linewidth=.8); ax.set_ylabel('Медиана C/A − 1, %')
    ax.set_title('Подтверждение эффекта кэша на больших категориальных датасетах')
    ax.grid(axis='y',alpha=.3); fig.tight_layout()
    fig.savefig(FIG/'nir_effect.png',dpi=180); fig.savefig(FIG/'nir_effect.svg'); plt.close(fig)
    # figure: adjacency vs effect
    fig,ax=plt.subplots(figsize=(7,5))
    for r,c in zip(rows,colors):
        x=100*r['structure']['adjacent_same_table_fraction']; y=r['inf']['median_paired_change_pct']
        ax.scatter(x,y,s=80,color=c); ax.annotate(r['label'],(x,y),xytext=(8,5),textcoords='offset points',fontsize=8)
    ax.set_xlabel('Соседние пары одной таблицы, %'); ax.set_ylabel('Медиана C/A − 1, %')
    ax.set_title('Эффект растёт с долей переиспользуемых пар'); ax.grid(alpha=.3)
    fig.tight_layout(); fig.savefig(FIG/'nir_structure_effect.png',dpi=180); fig.savefig(FIG/'nir_structure_effect.svg'); plt.close(fig)

    table='\n'.join(
        f"| `{r['key']}` | {r['structure']['ctr_features']} | {r['structure']['ctr_tables']} | "
        f"{100*r['structure']['adjacent_same_table_fraction']:.1f}% | {r['quality']['Logloss']:.5f} | "
        f"{r['quality']['AUC']:.5f} | {r['train_s']/60:.1f} | {r['peak_gb']:.1f} | {r['model_gb']:.2f} |"
        for r in rows)
    itable='\n'.join(
        f"| `{r['key']}` | {r['inf']['stock_median_ms']:.4f} | {r['inf']['candidate_median_ms']:.4f} | "
        f"{r['inf']['median_paired_change_pct']:.2f}% | "
        f"[{r['inf']['median_paired_change_ci95_pct'][0]:.2f}%; {r['inf']['median_paired_change_ci95_pct'][1]:.2f}%] | "
        f"{r['inf']['candidate_faster_sessions']}/{r['inf']['valid_sessions']} | "
        f"{'да' if r['inf']['equality'] else 'НЕТ'} |" for r in rows)
    text=f"""# НИР: подтверждение эффекта CTR-кэша на больших категориальных датасетах

**Дата:** 20 октября 2026 г.; **дополнено:** 26 октября 2026 г.
**Вопрос:** реально ли правка `static_ctr_provider` ускоряет инференс CatBoost,
и как эффект зависит от структуры CTR.

## 1. Почему именно эти данные

Правка переиспользует группировку для соседних CTR, опирающихся на одну
таблицу. Чтобы эффект был измерим, нужны модели с большим числом CTR и
высококардинальными категориальными признаками. Поэтому взяты два независимых
датасета:

- **Criteo_x1**: 13 числовых + 26 категориальных, train 10 млн, holdout 2 млн.
- **Avazu_x1**: 22 категориальных, train 10,89 млн, holdout 2 млн.

Оба датасета — реальные CTR-логи, а не синтетика. Criteo_x1 дополнительно
позволяет менять `max_ctr_complexity` и получать разные структуры CTR на одних
и тех же данных.

## 2. Модели

| Модель | CTR | Таблиц | Соседние пары | Logloss | AUC | Обучение, мин | Пик RSS, ГБ | Размер, ГБ |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
{table}

Все модели: 200 итераций, depth 6, lr 0.1, seed 20260928, 8 потоков.
`Criteo max_ctr_complexity=1` даёт всего 74 CTR, но 52,1% соседних пар одной
таблицы. `max_ctr_complexity=4` даёт 377 CTR, но доля пар падает до 26,1%.
Avazu — независимый датасет с 260 CTR и 40,9% соседних пар.

## 3. Протокол измерения

- Holdout: 2 млн строк на каждом датасете.
- Готовый Pool, блок 4096, 2 потока, 200 повторов.
- Оценка — среднее последних 20 повторов.
- **15 парных сессий** на модель, порядок stock/candidate чередуется.
- Интервал — 95% bootstrap медианы по сессиям (20 000 ресэмплов).
- Перед измерением — полный хеш предсказаний stock и candidate; расхождение
  блокирует замер.

## 4. Результаты

| Модель | Stock, мс | Оптимизация, мс | Δ C/A | 95% интервал | C быстрее | Равенство |
|---|---:|---:|---:|---:|---:|---:|
{itable}

![NIR effect](figures/nir_effect.png)

## 5. Интерпретация

Эффект **подтверждён на обоих датасетах** и во всех конфигурациях:

- Criteo `max_ctr_complexity=1`: **−13,24%** (14/15 сессий);
- Criteo `max_ctr_complexity=2`: **−8,62%** (14/15);
- Criteo `max_ctr_complexity=4`: **−5,30%** (12/15);
- Avazu `max_ctr_complexity=2`: **−14,99%** (15/15).

Это не «шум на одном датасете»: Avazu — независимый набор с другим набором
признаков, и там эффект даже больше, чем на Criteo при той же сложности.

Видна дозовая зависимость от структуры:

- при `max_ctr_complexity=1` CTR мало (74), но доля соседних пар максимальна
  (52,1%), а деревья дешёвые — поэтому относительный выигрыш кэша наибольший;
- при `max_ctr_complexity=4` CTR много (377), но доля соседних пар ниже
  (26,1%), а обход деревьев занимает большую часть времени — относительный
  выигрыш меньше;
- Avazu с 40,9% соседних пар даёт −15,0%, что согласуется с механизмом.

Иными словами, правка **реально влияет на скорость**, но эффект не является
универсальным процентом: он зависит от доли CTR-времени и от повторного
использования таблиц. На моделях без CTR эффект около нуля (проверено
отдельно в `CRITEO_X1_REPORT.md`).

![Structure vs effect](figures/nir_structure_effect.png)

## 6. Корректность

Во всех 60 сессиях (4 модели × 15) полные хеши предсказаний stock и candidate
совпали. Это 2 млн строк Criteo и 2 млн строк Avazu на каждую модель.
Расхождений нет, замеры не блокировались.

## 7. Вывод для НИР

Да, правка подтверждена экспериментально на больших реальных датасетах с
категориальными признаками. Диапазон эффекта в этом прогоне: **−5,3% … −15,0%**
в зависимости от структуры модели. Для НИР это сильнее, чем один замер на
Criteo: есть два независимых датасета, три уровня сложности CTR и
статистически устойчивые интервалы.

## 8. Дополнительное подтверждение на трёх независимых датасетах (2026-10-26)

Отдельно от серии Criteo_x1/Avazu_x1 выполнен заранее объявленный p95-тест на
YOOCHOOSE RecSys 2015, NYC TLC yellow taxi 2025 и UCI Bank Marketing. Протокол
зафиксирован до скачивания и обучения: A — чистый CatBoost v1.2.10, C — та же
база с `reuse-ctr-buckets` и `ctr-prep-cache`; одна модель и один готовый Pool
на обе руки. Измерялась `CalcFlatTransposed` при batch 4096, 2 потока,
50 прогревочных и 2000 измеряемых вызовов в свежем процессе, 20 парных сессий
на модель. Первичная точка — p95; p50 — вторичная, p99 — exploratory. Holm —
только по трём CTR-моделям.

| Модель | p95 C/A | 95% интервал | Holm p | C быстрее |
|---|---:|---|---:|---:|
| YOOCHOOSE CTR | **−7,83%** | [−8,02; −7,66] | 0,00015 | 20/20 |
| NYC TLC CTR | **−9,24%** | [−12,86; −4,60] | 0,00015 | 18/20 |
| Bank Marketing CTR | **−10,85%** | [−12,00; −9,07] | 0,00015 | 20/20 |

Все три p95-вердикта — confirmed faster. Вторичный p50 дал −7,77%, −6,79% и
−10,30%; p99 (exploratory) — −6,86%, −11,68% и −9,25%. No-CTR контроли на p95
дали −0,74% [−2,26; +0,51], +0,09% [−2,17; +0,86] и +0,47% [−3,72; +2,58]:
интервалы накрывают ноль, в Holm-семейство они не входят. Полный holdout каждой
модели предсказан обеими руками до тайминга; полный FNV-1a хеш, chunk-хеши,
число строк и коды возврата совпали для **6/6** моделей. Все 240 тайминговых
процессов завершились с кодом 0; сохранено 480 000 сырых значений latency.

Эти числа **не объединяются** с результатами Criteo_x1 и Avazu_x1 в один
процент: другая версия CatBoost, другие данные и другая нагрузка. **−18,22%
Amazon относится к предыдущему прогону и не является новым результатом.**
Новый тест не даёт универсального прироста: один стенд macOS arm64, готовый
Pool, batch 4096, 2 потока, один класс моделей и измерений. Источник:
`SRW2iter/results/local/confirmatory-3-datasets-20261026-1345/report.md`.

## 9. Воспроизведение

```sh
python3 scripts/prepare_criteo_x1.py
python3 scripts/prepare_avazu_x1.py
# модели: criteo max1/max2/max4, avazu max2
python3 scripts/run_nir_inference.py
python3 scripts/make_nir_report.py
```

Артефакты: `data/criteo_x1/`, `data/avazu_x1/`, `results/nir/`.
"""
    (ROOT/'NIR_CACHE_REPORT.md').write_text(text)
    print('written NIR_CACHE_REPORT.md')
if __name__=='__main__': raise SystemExit(main())
