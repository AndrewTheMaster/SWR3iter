#!/usr/bin/env python3
"""Paired stock-vs-optimized inference for the NIR cache experiments."""
from __future__ import annotations
import json, sys
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'scripts'))
import run_inference as ri
SESSIONS = 15
OUT = ROOT / 'results/nir/inference'

def specs():
    for name, model in [
        ('criteo_max4', ROOT/'results/criteo_x1/cache_model/model.cbm'),
        ('criteo_max2', ROOT/'results/nir/criteo_max2/model.cbm'),
        ('criteo_max1', ROOT/'results/nir/criteo_max1/model.cbm'),
    ]:
        yield {'name': name, 'group':'criteo', 'model': model,
               'pool': ROOT/'data/criteo_x1/holdout_ctr.dsv',
               'cd': ROOT/'data/criteo_x1/full.cd'}
    yield {'name':'avazu_max2','group':'avazu',
           'model': ROOT/'results/nir/avazu_max2/model.cbm',
           'pool': ROOT/'data/avazu_x1/holdout.dsv',
           'cd': ROOT/'data/avazu_x1/train.cd'}

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(ri.SEED)
    records=[]
    for spec in specs():
        d=OUT/spec['name']; d.mkdir(parents=True, exist_ok=True)
        pairs=[]; equality=True
        for session in range(1,SESSIONS+1):
            order=('stock','candidate') if session%2 else ('candidate','stock')
            res={}
            for arm in order:
                out=d/f'session-{session:02d}-{arm}.json'
                res[arm]=ri.run_arm(spec['model'],spec['pool'],spec['cd'],arm,out)
            s,c=res['stock'],res['candidate']
            sh=(s.get('full_dataset') or {}).get('pred_hash_full')
            ch=(c.get('full_dataset') or {}).get('pred_hash_full')
            same=bool(sh and ch and sh==ch and s.get('pred_hash')==c.get('pred_hash')
                      and s.get('process_exit_code')==0 and c.get('process_exit_code')==0)
            equality=equality and same
            if not same:
                pairs.append({'session':session,'error':'hash/process mismatch'}); continue
            a=float(s['per_rep_ms']['last_decile']); b=float(c['per_rep_ms']['last_decile'])
            pairs.append({'session':session,'stock_ms':a,'candidate_ms':b,
                          'change_pct':100.0*(b/a-1.0),'order':'-'.join(order)})
        valid=[p for p in pairs if 'change_pct' in p]
        ch=np.array([p['change_pct'] for p in valid])
        summ={**{k:(str(v) if isinstance(v,Path) else v) for k,v in spec.items()},
              'model_sha256':ri.sha256(spec['model']),'sessions':SESSIONS,
              'block_size':ri.BLOCK,'threads':ri.THREADS,'repetitions':ri.REPETITIONS,
              'equality':equality,'pairs':pairs}
        if len(valid)>=3:
            summ.update({'stock_median_ms':float(np.median([p['stock_ms'] for p in valid])),
                         'candidate_median_ms':float(np.median([p['candidate_ms'] for p in valid])),
                         'median_paired_change_pct':float(np.median(ch)),
                         'median_paired_change_ci95_pct':ri.bootstrap_median(ch,rng),
                         'candidate_faster_sessions':int((ch<0).sum()),
                         'valid_sessions':len(valid)})
        (d/'summary.json').write_text(json.dumps(summ,indent=2,ensure_ascii=False)+'\n')
        records.append(summ)
        print(spec['name'], 'eq', equality, 'delta', summ.get('median_paired_change_pct'), flush=True)
    (OUT/'records.json').write_text(json.dumps(records,indent=2,ensure_ascii=False)+'\n')
    return 0
if __name__=='__main__': raise SystemExit(main())
