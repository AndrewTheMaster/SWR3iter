#!/usr/bin/env python3
"""Paired stock-vs-optimized inference for the Criteo_x1 cache model and numeric controls."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'scripts'))
import run_inference as ri

SESSIONS = 9
OUT = ROOT / 'results/criteo_x1/inference'


def specs():
    yield {
        'name': 'criteo_x1_ctr_10m',
        'group': 'ctr',
        'model': ROOT / 'results/criteo_x1/cache_model/model.cbm',
        'pool': ROOT / 'data/criteo_x1/holdout_ctr.dsv',
        'cd': ROOT / 'data/criteo_x1/full.cd',
    }
    for tag in ('single3', 'single12', 'dist1', 'dist2', 'dist4'):
        yield {
            'name': f'criteo_x1_num_{tag}',
            'group': 'no_ctr',
            'model': ROOT / f'results/criteo_x1/numeric_models/{tag}/model.cbm',
            'pool': ROOT / 'data/criteo_x1/holdout_num.dsv',
            'cd': ROOT / 'data/criteo_x1/num.cd',
        }


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(ri.SEED)
    records = []
    for spec in specs():
        d = OUT / spec['name']
        d.mkdir(parents=True, exist_ok=True)
        pairs = []
        equality = True
        hashes = {'stock': set(), 'candidate': set()}
        for session in range(1, SESSIONS + 1):
            order = ('stock', 'candidate') if session % 2 else ('candidate', 'stock')
            res = {}
            for arm in order:
                out = d / f'session-{session:02d}-{arm}.json'
                res[arm] = ri.run_arm(spec['model'], spec['pool'], spec['cd'], arm, out)
            s, c = res['stock'], res['candidate']
            sh = (s.get('full_dataset') or {}).get('pred_hash_full')
            ch = (c.get('full_dataset') or {}).get('pred_hash_full')
            hashes['stock'].add(sh); hashes['candidate'].add(ch)
            same = bool(sh and ch and sh == ch and s.get('pred_hash') == c.get('pred_hash')
                        and s.get('process_exit_code') == 0 and c.get('process_exit_code') == 0)
            equality = equality and same
            if not same:
                pairs.append({'session': session, 'error': 'hash or process mismatch',
                              'stock_hash': sh, 'candidate_hash': ch})
                continue
            a = float(s['per_rep_ms']['last_decile'])
            b = float(c['per_rep_ms']['last_decile'])
            pairs.append({'session': session, 'stock_ms': a, 'candidate_ms': b,
                          'change_pct': 100.0 * (b / a - 1.0),
                          'order': '-'.join(order)})
        valid = [p for p in pairs if 'change_pct' in p]
        ch = np.array([p['change_pct'] for p in valid])
        summary = {
            **{k: (str(v) if isinstance(v, Path) else v) for k, v in spec.items()},
            'model_sha256': ri.sha256(spec['model']),
            'sessions': SESSIONS, 'block_size': ri.BLOCK, 'threads': ri.THREADS,
            'repetitions': ri.REPETITIONS, 'equality': equality,
            'hashes': {k: sorted(x for x in v if x) for k, v in hashes.items()},
            'pairs': pairs,
        }
        if len(valid) >= 3:
            summary.update({
                'stock_median_ms': float(np.median([p['stock_ms'] for p in valid])),
                'candidate_median_ms': float(np.median([p['candidate_ms'] for p in valid])),
                'median_paired_change_pct': float(np.median(ch)),
                'median_paired_change_ci95_pct': ri.bootstrap_median(ch, rng),
                'candidate_faster_sessions': int((ch < 0).sum()),
                'valid_sessions': len(valid),
            })
        (d / 'summary.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False) + '\n')
        records.append(summary)
        print(f"{spec['name']:24s} eq={equality} "
              f"{summary.get('stock_median_ms', float('nan')):.4f}/"
              f"{summary.get('candidate_median_ms', float('nan')):.4f} ms "
              f"delta={summary.get('median_paired_change_pct')}", flush=True)
    (OUT / 'records.json').write_text(json.dumps(records, indent=2, ensure_ascii=False) + '\n')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
