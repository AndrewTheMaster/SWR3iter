#!/usr/bin/env python3
"""Build the main Criteo_x1 report and figures from the recorded runs."""
from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
R = ROOT / 'results/criteo_x1'
FIG = ROOT / 'figures'
FIG.mkdir(exist_ok=True)


def load(p):
    return json.loads(Path(p).read_text())


def last_metric(path):
    rows = list(csv.reader(Path(path).open(), delimiter='\t'))
    return {k: float(v) for k, v in zip(rows[0], rows[-1])}


def main() -> int:
    data = load(ROOT / 'data/criteo_x1/manifest.json')
    struct = load(R / 'cache_model/structure.json')[0]
    quality = last_metric(R / 'cache_model/metrics.tsv')
    num = load(R / 'numeric_models/records.json')
    inf = load(R / 'inference/records.json')
    inf_by = {x['name']: x for x in inf}
    num_by = {x['name'].replace('criteo_x1_', ''): x for x in num}

    # Training time figure.
    tags = ['single3', 'single12', 'dist1', 'dist2', 'dist4']
    vals = [num_by[t]['fit_wall_s'] for t in tags]
    colors = ['#9e9e9e', '#2ca02c', '#9ecae1', '#4292c6', '#08519c']
    fig, ax = plt.subplots(figsize=(9, 4.8))
    bars = ax.bar(tags, vals, color=colors)
    for b, v in zip(bars, vals):
        ax.text(b.get_x() + b.get_width()/2, v + 2, f'{v:.1f} s', ha='center', fontsize=9)
    ax.set_ylabel('Время обучения, с')
    ax.set_title('Criteo_x1: 18,84 млн строк, 13 числовых признаков, 200 итераций')
    ax.grid(axis='y', alpha=0.3)
    fig.tight_layout()
    fig.savefig(FIG / 'criteo_x1_training_time.png', dpi=180)
    fig.savefig(FIG / 'criteo_x1_training_time.svg')
    plt.close(fig)

    # Inference effect figure.
    names = ['criteo_x1_ctr_10m'] + [f'criteo_x1_num_{t}' for t in tags]
    labels = ['CTR 10M'] + [f'num {t}' for t in tags]
    vals = [inf_by[n]['median_paired_change_pct'] for n in names]
    cis = [inf_by[n]['median_paired_change_ci95_pct'] for n in names]
    vals = np.array(vals); cis = np.array(cis)
    err = np.vstack([vals - cis[:, 0], cis[:, 1] - vals])
    fig, ax = plt.subplots(figsize=(9, 4.8))
    colors = ['#1f77b4'] + ['#7f7f7f'] * len(tags)
    ax.bar(labels, vals, yerr=err, capsize=4, color=colors)
    ax.axhline(0, color='black', linewidth=0.8)
    ax.set_ylabel('Медиана C/A − 1, %')
    ax.set_title('Criteo_x1: эффект CTR-оптимизации на инференсе')
    ax.grid(axis='y', alpha=0.3)
    fig.tight_layout()
    fig.savefig(FIG / 'criteo_x1_inference_effect.png', dpi=180)
    fig.savefig(FIG / 'criteo_x1_inference_effect.svg')
    plt.close(fig)

    # Structure vs effect across datasets (pilot + new).
    points = [
        ('Amazon', 52.83, -19.26, '#d62728'),
        ('KDD', 13.25, -8.66, '#2ca02c'),
        ('Criteo sample', 16.67, -4.56, '#ff7f0e'),
        ('Criteo_x1', struct['adjacent_same_table_fraction'] * 100,
         inf_by['criteo_x1_ctr_10m']['median_paired_change_pct'], '#1f77b4'),
    ]
    fig, ax = plt.subplots(figsize=(7, 5))
    for name, x, y, color in points:
        ax.scatter(x, y, s=70, color=color)
        ax.annotate(name, (x, y), textcoords='offset points', xytext=(8, 6), fontsize=9)
    ax.set_xlabel('Доля соседних пар CTR с одной таблицей, %')
    ax.set_ylabel('Медиана C/A − 1, %')
    ax.set_title('Эффект кэша и структура CTR (не только доля соседних пар)')
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(FIG / 'ctr_effect_vs_structure.png', dpi=180)
    fig.savefig(FIG / 'ctr_effect_vs_structure.svg')
    plt.close(fig)

    def row(tag):
        r = num_by[tag]; q = r['quality']
        return f"| `{tag}` | {r['fit_wall_s']:.2f} | {q['Logloss']:.6f} | {q['AUC']:.6f} |"

    def irow(name, label):
        r = inf_by[name]; ci = r['median_paired_change_ci95_pct']
        return (f"| `{label}` | {r['stock_median_ms']:.4f} | {r['candidate_median_ms']:.4f} | "
                f"{r['median_paired_change_pct']:.2f}% | [{ci[0]:.2f}%; {ci[1]:.2f}%] | "
                f"{r['candidate_faster_sessions']}/{r['valid_sessions']} | "
                f"{'да' if r['equality'] else 'НЕТ'} |")

    s3 = inf_by['criteo_x1_ctr_10m']
    speed = {t: num_by['single3']['fit_wall_s'] / num_by[t]['fit_wall_s'] for t in tags}
    text = f"""# Criteo_x1: распределённое обучение и проверка CTR-кэша

**Дата:** 20 октября 2026 г.
**Данные:** Criteo_x1 (Kaggle Display Advertising), 13 числовых + 26 категориальных
признаков, 45,84 млн строк в полном наборе.
**Использовано:** 15 parquet-шардов (23,5 млн строк):
12 шардов train (18 837 167 строк), 3 шарда holdout (4 710 000 строк).
Для CTR-модели — 10 000 000 train и 2 000 000 holdout.
**Причина такого размера:** сеть на стенде даёт ~1 МБ/с; полный Criteo 1TB
(276 ГБ) физически не скачать за разумное время. Criteo_x1 — тот же тип данных,
использованные 15 шардов — 1,9 ГБ parquet; distributed-train вырос с 1,56 до 18,84 млн строк (12×), CTR-train — до 10 млн (6,4×).

## 1. Что проверено

1. **Базовая линия:** CTR-модель на 10 млн строк, качество, структура CTR,
   время обучения и инференса.
2. **Распределённое обучение:** SingleHost 3/12 потоков против 1/2/4
   worker-процессов на 18,84 млн строк, 13 числовых признаков, 200 итераций.
3. **Проверка фикса кэша:** stock vs optimized на 2 млн holdout, 9 парных
   сессий, полный хеш предсказаний.
4. **Отрицательный контроль:** те же измерения на пяти numeric-моделях без CTR.

## 2. Данные и split

- Источник: `reczoo/Criteo_x1`, parquet-ветка Hugging Face.
- Shards 0000–0011 — train, 0012–0014 — holdout. Split зафиксирован до обучения.
- `train_num.dsv`: 18 837 167 строк, label + I1..I13, 1,14 ГБ.
- `holdout_num.dsv`: 4 710 000 строк, 286 МБ.
- `train_ctr.dsv`: 10 000 000 строк, все 39 признаков, 2,49 ГБ.
- `holdout_ctr.dsv`: 2 000 000 строк, 498 МБ.
- CD: `0 Target`, `1..13 Num`, `14..39 Categ`.
- Полные SHA-256 — в `data/criteo_x1/manifest.json`.

## 3. CTR-модель и структура

| Параметр | Значение |
|---|---:|
| Обучение | 200 итераций, depth 6, lr 0.1, seed 20260928, 8 потоков |
| Время обучения | **18,64 мин** (1118,7 с) |
| Пиковый RSS | **16,3 ГБ** |
| Размер модели | **2,5 ГБ** |
| CTR-признаков | **{struct['ctr_features']}** |
| Таблиц | **{struct['ctr_tables']}** |
| Проекций | **{struct['projections']}** |
| CTR на проекцию | {struct['ctr_per_projection']:.2f} |
| Соседних пар одной таблицы | **{struct['adjacent_same_table_pairs']} ({100*struct['adjacent_same_table_fraction']:.1f}%)** |
| Logloss / AUC на holdout | **{quality['Logloss']:.5f} / {quality['AUC']:.5f}** |

Это уже не игрушечная модель: 377 CTR-признаков, 279 таблиц, 2,5 ГБ.
Для сравнения, старый Criteo-пилот: 355 CTR, 296 таблиц, 452 МБ.

## 4. Распределённое обучение

Все конфигурации: 18,84 млн строк, 13 числовых признаков, 200 итераций,
один seed. У distributed-конфигураций по 3 потока на worker, master — 2 потока.

| Конфигурация | Время, с | Logloss | AUC |
|---|---:|---:|---:|
{row('single3')}
{row('single12')}
{row('dist1')}
{row('dist2')}
{row('dist4')}

Скорость относительно `single3`:

- `single12`: **{speed['single12']:.2f}×**
- `dist1`: **{speed['dist1']:.2f}×** (медленнее single-host)
- `dist2`: **{speed['dist2']:.2f}×**
- `dist4`: **{speed['dist4']:.2f}×**

От `dist1` к `dist4` — **{num_by['dist1']['fit_wall_s']/num_by['dist4']['fit_wall_s']:.2f}×**.
Это уже настоящий scaling: 4 worker-а заметно быстрее 1 и 2, хотя на одной
машине всё ещё проигрывают `single12`, который использует все 12 потоков
одного процесса. Качество всех конфигураций практически одинаковое:
ΔLogloss ≤ 0,00003, ΔAUC ≤ 0,00002.

Главный вывод: **на 18,8 млн строк распределённое обучение имеет смысл**
(в отличие от 1,5 млн строк, где накладные расходы съедали всё). Для
дальнейшего масштаба нужно 2–4 физические VM, а не процессы на одном хосте.

![Criteo_x1 training time](figures/criteo_x1_training_time.png)

## 5. Проверка фикса кэша

Модель: `criteo_x1_ctr_10m`, holdout 2 000 000 строк, блок 4096, 2 потока,
200 повторов, 9 парных сессий.

| Модель | Stock, мс | Оптимизация, мс | Δ C/A | 95% интервал | C быстрее | Равенство |
|---|---:|---:|---:|---:|---:|---:|
{irow('criteo_x1_ctr_10m', 'CTR 10M')}

Итог: **−{abs(s3['median_paired_change_pct']):.2f}%**,
95% интервал [{s3['median_paired_change_ci95_pct'][0]:.2f}%; {s3['median_paired_change_ci95_pct'][1]:.2f}%], 9/9 сессий.
Полные хеши предсказаний stock и candidate совпали на всех 2 млн строк.

### Отрицательный контроль

Пять numeric-моделей без CTR (single-host и distributed), тот же holdout
4,71 млн строк:

| Модель | Δ C/A | 95% интервал | C быстрее | Равенство |
|---|---:|---:|---:|---:|
"""
    for t in tags:
        r = inf_by[f'criteo_x1_num_{t}']; ci = r['median_paired_change_ci95_pct']
        text += (f"| `{t}` | {r['median_paired_change_pct']:.2f}% | "
                 f"[{ci[0]:.2f}%; {ci[1]:.2f}%] | "
                 f"{r['candidate_faster_sessions']}/{r['valid_sessions']} | "
                 f"{'да' if r['equality'] else 'НЕТ'} |\n")
    text += f"""
Все интервалы на моделях без CTR накрывают ноль; максимальная по модулю
медиана — 0,50%. Это подтверждает, что выигрыш даёт именно CTR-путь, а не
общие накладные расходы.

![Criteo_x1 inference effect](figures/criteo_x1_inference_effect.png)

## 6. Связь эффекта со структурой CTR

| Датасет/модель | CTR | Таблиц | Соседние пары одной таблицы | Δ C/A |
|---|---:|---:|---:|---:|
| Amazon | 160 | 76 | 52,8% | −19,26% |
| KDD | 386 | 335 | 13,2% | −8,66% |
| Criteo sample (1,5M) | 355 | 296 | 16,7% | −4,56% |
| **Criteo_x1 (10M)** | **377** | **279** | **26,1%** | **−6,53%** |

Доля соседних пар выросла с 16,7% до 26,1%, и эффект вырос с −4,56% до
−6,53%. Это согласуется с механизмом правки. Но одной доли мало: у KDD доля
ниже, чем у Criteo_x1, а эффект больше. Значит, важны ещё число CTR, размер
таблиц и доля времени в CTR-вычислении. Корректная формулировка: эффект
зависит от структуры модели, а не от числа worker-ов; distributed CPU вообще
не создаёт CTR, поэтому на distributed-моделях эффект нулевой.

![Structure vs effect](figures/ctr_effect_vs_structure.png)

## 7. Выводы

1. **Criteo_x1 подходит под обе задачи**: 13 числовых признаков дают
   distributed-обучение с реальным scaling, 26 категориальных — модель с
   богатой CTR-структурой для проверки кэша.
2. **Кэш-фикс подтверждён на серьёзной модели:** −6,53% на 2 млн holdout,
   9/9 сессий, побитовое равенство.
3. **Distributed CPU по-прежнему не умеет CTR** — это ограничение CatBoost,
   а не данных. CTR-модель обучалась single-host; distributed-эксперимент
   сознательно использует только 13 числовых признаков.
4. Для 1/2/4 worker-ов на одной машине distributed обгоняет SingleHost-3,
   но не SingleHost-12. Для дальнейшего scaling нужны физические VM.
5. Пиковый RSS CTR-модели — 16,3 ГБ; 24 ГБ достаточно, 46 ГБ дают запас.
   Диск: 1,9 ГБ parquet + 4,2 ГБ DSV + 2,5 ГБ модель ≈ 9 ГБ,
   что укладывается в 50 ГБ.

## 8. Воспроизведение

```sh
cd "/Users/a.baryaev/Documents/itmo/Distributet ML"

# Данные: 15 parquet-шардов Criteo_x1 уже в data/criteo_x1_parquet
python3 scripts/prepare_criteo_x1.py

# CTR-модель
catboost fit --learn-set data/criteo_x1/train_ctr.dsv \\
  --column-description data/criteo_x1/full.cd \\
  --loss-function Logloss --iterations 200 --depth 6 --learning-rate 0.1 \\
  --random-seed 20260928 --thread-count 8 \\
  --model-file results/criteo_x1/cache_model/model.cbm \\
  --allow-writing-files false

# Distributed numeric
python3 - <<'PY'
import sys, json
from pathlib import Path
sys.path.insert(0, 'scripts')
import run_training as rt
spec = {{'train': Path('data/criteo_x1/train_num.dsv'),
        'holdout': Path('data/criteo_x1/holdout_num.dsv'),
        'cd': Path('data/criteo_x1/num.cd')}}
for tag, mode, threads, workers in [('single3','single',3,0), ('single12','single',12,0),
                                    ('dist1','dist',3,1), ('dist2','dist',3,2),
                                    ('dist4','dist',3,4)]:
    rt.train_one(f'criteo_x1_{{tag}}', spec, Path(f'results/criteo_x1/numeric_models/{{tag}}'),
                 mode=mode, threads=threads, iterations=200, extra=[], workers=workers,
                 base_port=26000)
PY

# Инференс
python3 scripts/run_criteo_x1_inference.py
```

Артефакты: `results/criteo_x1/`, `data/criteo_x1/`, `data/criteo_x1_parquet/`.
"""
    (ROOT / 'CRITEO_X1_REPORT.md').write_text(text)
    (ROOT / 'CRITEO_X1_REPORT.html').write_text('')  # filled by build_html
    print('written', ROOT / 'CRITEO_X1_REPORT.md')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
